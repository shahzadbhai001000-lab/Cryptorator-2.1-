package app.safegallery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * "Send to vault" in the share menu of other apps. It asks which vault, and then puts the files in without a
 * password: they are sealed with the public key of the vault and wait in its inbox until the vault is next unlocked.
 */
public class ShareActivity extends Activity {

	private static final int REQ_DELETE = 7;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		final List<Uri> uris = new ArrayList<>();
		Intent intent = getIntent();
		ClipData clip = intent.getClipData();
		if (clip != null) {
			for (int i = 0; i < clip.getItemCount(); i++) {
				if (clip.getItemAt(i).getUri() != null) {
					uris.add(clip.getItemAt(i).getUri());
				}
			}
		}
		if (uris.isEmpty()) {
			Uri single = intent.getParcelableExtra(Intent.EXTRA_STREAM);
			if (single != null) {
				uris.add(single);
			}
		}
		final List<String[]> vaults = Vaults.list(this);
		if (uris.isEmpty()) {
			toast("Nothing to send");
			finish();
			return;
		}
		if (vaults.isEmpty()) {
			toast("Open the app and create a vault first");
			finish();
			return;
		}
		final String[] names = new String[vaults.size()];
		for (int i = 0; i < names.length; i++) {
			names[i] = vaults.get(i)[0];
		}
		final String hint = intent.getType();
		new AlertDialog.Builder(this)
				.setTitle("Send " + uris.size() + " file(s) to which vault?")
				.setItems(names, (d, which) -> send(vaults.get(which), uris, hint))
				.setOnCancelListener(d -> finish())
				.show();
	}

	private void send(final String[] vault, final List<Uri> uris, final String hint) {
		final boolean move = Settings.shareMove(this);
		final boolean clean = Settings.autoClean(this);
		final Uri tree = Uri.parse(vault[1]);
		Toast.makeText(this, "Sending…", Toast.LENGTH_SHORT).show();
		new Thread(() -> {
			int ok = 0;
			int failed = 0;
			String problem = null;
			final List<Uri> done = new ArrayList<>();
			try {
				SafStore store = new SafStore(this, tree);
				Vault open = Session.isUnlocked(tree) ? Session.vault : null;
				byte[] publicKey = open == null ? Vault.readPublicKey(store) : null;
				if (open == null && publicKey == null) {
					problem = "Open this vault once in the app, then sharing works";
				} else {
					Store inbox = open == null ? store.child(Vault.INBOX, true) : null;
					for (Uri uri : uris) {
						try (Importer.Prepared p = Importer.prepare(this, uri, hint, clean)) {
							if (open != null) {
								Index.Entry entry = open.addFile(p.data.stream, p.name, p.mime, "", p.thumbnail);
								try {
									p.data.check();
								} catch (IOException e) {
									List<Index.Entry> one = new ArrayList<>();
									one.add(entry);
									open.delete(one);
									throw e;
								}
							} else {
								Inbox.deposit(inbox, publicKey, p.name, p.mime, p.thumbnail, p.data.stream);
								p.data.check();
							}
							ok++;
							done.add(uri);
						} catch (Exception e) {
							failed++;
						}
					}
				}
			} catch (Exception e) {
				problem = "Could not reach the vault folder";
			}
			final int okCount = ok;
			final int failCount = failed;
			final String error = problem;
			runOnUiThread(() -> finishSend(okCount, failCount, error, move ? done : new ArrayList<Uri>()));
		}).start();
	}

	private List<Uri> needsConfirm = new ArrayList<>();

	private void finishSend(int ok, int failed, String problem, List<Uri> toDelete) {
		if (problem != null) {
			toast(problem);
			finish();
			return;
		}
		String text = ok + " file(s) sent to the vault" + (failed > 0 ? ", " + failed + " failed" : "");
		int stuck = 0;
		needsConfirm = new ArrayList<>();
		for (Uri uri : toDelete) {
			try {
				boolean gone;
				if (DocumentsContract.isDocumentUri(this, uri)) {
					gone = DocumentsContract.deleteDocument(getContentResolver(), uri);
				} else {
					gone = getContentResolver().delete(uri, null, null) > 0;
				}
				if (!gone) {
					stuck++;
				}
			} catch (SecurityException e) {
				if ("media".equals(uri.getAuthority()) && Build.VERSION.SDK_INT >= 30) {
					needsConfirm.add(uri);
				} else {
					stuck++;
				}
			} catch (Exception e) {
				stuck++;
			}
		}
		if (stuck > 0) {
			text += ". The app that shared the file does not allow deleting " + stuck + " original(s)";
		}
		toast(text);
		if (!needsConfirm.isEmpty()) {
			try {
				IntentSender sender = MediaStore.createDeleteRequest(getContentResolver(), needsConfirm).getIntentSender();
				startIntentSenderForResult(sender, REQ_DELETE, null, 0, 0, 0);
				return;
			} catch (Exception e) {
				toast("Android needs your confirmation to delete the originals; delete them in your gallery");
			}
		}
		finish();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		finish();
	}

	private void toast(String text) {
		Toast.makeText(this, text, Toast.LENGTH_LONG).show();
	}
}
