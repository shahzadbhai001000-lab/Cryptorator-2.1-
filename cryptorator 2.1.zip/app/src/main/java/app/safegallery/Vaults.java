package app.safegallery;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** The list of vaults the person has opened or created on this phone: {name, folder uri}. */
final class Vaults {

	private static final String PREFS = "vaults";
	private static final String KEY = "list";

	private Vaults() {
	}

	static List<String[]> list(Context context) {
		List<String[]> result = new ArrayList<>();
		SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
		for (String s : prefs.getStringSet(KEY, new HashSet<String>())) {
			String[] parts = s.split("\t", 2);
			if (parts.length == 2) {
				result.add(parts);
			}
		}
		Collections.sort(result, (a, b) -> a[0].compareToIgnoreCase(b[0]));
		return result;
	}

	private static void save(Context context, List<String[]> vaults) {
		Set<String> set = new HashSet<>();
		for (String[] v : vaults) {
			set.add(v[0] + "\t" + v[1]);
		}
		context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY, set).apply();
	}

	static void add(Context context, String name, String tree) {
		List<String[]> vaults = list(context);
		for (String[] v : vaults) {
			if (v[1].equals(tree)) {
				return;
			}
		}
		vaults.add(new String[]{name, tree});
		save(context, vaults);
	}

	static void remove(Context context, String tree) {
		List<String[]> vaults = list(context);
		for (int i = vaults.size() - 1; i >= 0; i--) {
			if (vaults.get(i)[1].equals(tree)) {
				vaults.remove(i);
			}
		}
		save(context, vaults);
	}
}
