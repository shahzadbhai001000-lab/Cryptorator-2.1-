package app.safegallery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

	private static final int REQ_CREATE = 1;
	private static final int REQ_OPEN = 2;
	private List<String[]> vaults = new ArrayList<>(); // {name, tree uri}
	private ArrayAdapter<String> adapter;
	private AlertDialog busy;
	private TextView titleView;

	private interface PasswordCallback {
		void ok(char[] password);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (Session.vault != null) {
			startActivity(new Intent(this, VaultActivity.class));
		}
		if (Settings.blockScreenshots(this)) {
			getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
		}
		int pad = (int) (16 * getResources().getDisplayMetrics().density);
		LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(pad, pad, pad, pad);
		root.setBackgroundColor(Color.BLACK);

		TextView title = new TextView(this);
		title.setText(Disguise.name(this));
		title.setTextColor(Color.WHITE);
		title.setTextSize(26);
		title.setGravity(Gravity.CENTER);
		root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

		Button create = new Button(this);
		create.setText("Create new vault");
		create.setOnClickListener(v -> pickFolder(REQ_CREATE));
		root.addView(create);

		Button open = new Button(this);
		open.setText("Open existing vault");
		open.setOnClickListener(v -> pickFolder(REQ_OPEN));
		root.addView(open);

		TextView hint = new TextView(this);
		hint.setText("Your vaults (long-press for options)");
		hint.setTextColor(0xFF9E9E9E);
		hint.setPadding(0, pad, 0, pad / 2);
		root.addView(hint);

		ListView list = new ListView(this);
		adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
		list.setAdapter(adapter);
		list.setOnItemClickListener((parent, view, position, id) -> open(Uri.parse(vaults.get(position)[1]), vaults.get(position)[0]));
		list.setOnItemLongClickListener((parent, view, position, id) -> {
			final int index = position;
			final String tree = vaults.get(index)[1];
			final boolean fingerprint = Biometrics.enabled(this, tree);
			String[] options = fingerprint ? new String[]{"Turn off fingerprint unlock", "Remove from this list"} : new String[]{"Remove from this list"};
			new AlertDialog.Builder(this).setTitle(vaults.get(index)[0]).setItems(options, (d, which) -> {
				if (fingerprint && which == 0) {
					Biometrics.disable(this, tree);
					toast("Fingerprint unlock is off");
				} else {
					Vaults.remove(this, tree);
					Biometrics.disable(this, tree);
					loadVaults();
					showVaults();
				}
			}).show();
			return true;
		});
		root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
		this.titleView = title;
		setContentView(root);
		Disguise.apply(this);

		loadVaults();
		showVaults();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 2, 0, "Settings").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == 2) {
			startActivity(new Intent(this, SettingsActivity.class));
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onResume() {
		super.onResume();
		Disguise.apply(this);
		titleView.setText(Disguise.name(this));
		loadVaults();
		showVaults();
	}

	// ----- saved vaults -----

	private void loadVaults() {
		vaults = Vaults.list(this);
	}

	private void showVaults() {
		adapter.clear();
		for (String[] v : vaults) {
			adapter.add(v[0]);
		}
	}

	private void remember(Uri tree, String name) {
		Vaults.add(this, name, tree.toString());
		runOnUiThread(() -> {
			loadVaults();
			showVaults();
		});
	}

	// ----- picking a folder -----

	private void pickFolder(int request) {
		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
		startActivityForResult(intent, request);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != RESULT_OK || data == null || data.getData() == null) {
			return;
		}
		final Uri tree = data.getData();
		try {
			getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		} catch (SecurityException e) {
			toast("Could not keep access to this folder");
			return;
		}
		final String name = folderName(tree);
		if (requestCode == REQ_CREATE) {
			askPassword("New vault \"" + name + "\"", true, password -> runBusy("Creating vault…", () -> {
				Vault vault = Vault.create(new SafStore(this, tree), password);
				Session.unlocked(vault, tree);
				remember(tree, name);
			}, () -> offerFingerprint(tree)));
		} else if (requestCode == REQ_OPEN) {
			open(tree, name);
		}
	}

	private String folderName(Uri tree) {
		Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
		try (Cursor c = getContentResolver().query(doc, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
			if (c != null && c.moveToFirst() && c.getString(0) != null) {
				return c.getString(0);
			}
		} catch (Exception ignored) {
			// falls back to a general name
		}
		return "Vault";
	}

	// ----- unlocking -----

	/** Uses the fingerprint if it is set up for the vault, and the password otherwise. */
	private void open(final Uri tree, final String name) {
		if (!Biometrics.enabled(this, tree.toString())) {
			unlock(tree, name);
			return;
		}
		Biometrics.unlock(this, tree.toString(), new Biometrics.Result() {
			@Override
			public void ok(byte[] secret) {
				if (secret.length != 33 || secret[0] != 'K') {
					// a fingerprint set up by an older version stored the password: ask for it once and set it up again
					Biometrics.disable(MainActivity.this, tree.toString());
					toast("Please unlock with your password once to update fingerprint unlock");
					unlock(tree, name);
					return;
				}
				final byte[] key = java.util.Arrays.copyOfRange(secret, 1, 33);
				runBusy("Unlocking…", () -> {
					Vault vault = Vault.openWithKey(new SafStore(MainActivity.this, tree), key);
					Session.unlocked(vault, tree);
				}, MainActivity.this::startVault);
			}

			@Override
			public void fail(String message) {
				if (message != null) {
					toast(message);
				}
				unlock(tree, name);
			}
		});
	}

	private void unlock(final Uri tree, final String name) {
		askPassword("Unlock \"" + name + "\"", false, password -> runBusy("Unlocking…", () -> {
			Vault vault = Vault.open(new SafStore(this, tree), password);
			Session.unlocked(vault, tree);
			remember(tree, name);
		}, () -> offerFingerprint(tree)));
	}

	private void offerFingerprint(final Uri tree) {
		if (!Biometrics.available(this) || Biometrics.enabled(this, tree.toString())) {
			startVault();
			return;
		}
		new AlertDialog.Builder(this).setTitle("Fingerprint unlock").setMessage("Unlock this vault with your fingerprint next time?").setCancelable(false).setNegativeButton("Not now", (d, w) -> startVault()).setPositiveButton("Turn on", (d, w) -> {
			byte[] key = Session.vault.keyBytes();
			byte[] secret = new byte[33];
			secret[0] = 'K';
			System.arraycopy(key, 0, secret, 1, 32);
			Biometrics.enable(this, tree.toString(), secret, new Biometrics.Result() {
				@Override
				public void ok(byte[] ignored) {
					toast("Fingerprint unlock is on");
					startVault();
				}

				@Override
				public void fail(String message) {
					if (message != null) {
						toast(message);
					}
					startVault();
				}
			});
		}).show();
	}

	private void startVault() {
		startActivity(new Intent(this, VaultActivity.class));
	}

	private interface Job {
		void run() throws Exception;
	}

	private void runBusy(String message, final Job job, final Runnable onSuccess) {
		busy = new AlertDialog.Builder(this).setMessage(message).setCancelable(false).show();
		new Thread(() -> {
			String error = null;
			try {
				job.run();
			} catch (Vault.WrongPasswordException e) {
				error = "Wrong password";
			} catch (Exception e) {
				error = e.getMessage() != null ? e.getMessage() : e.toString();
			}
			final String message1 = error;
			runOnUiThread(() -> {
				busy.dismiss();
				if (message1 != null) {
					toast(message1);
				} else {
					onSuccess.run();
				}
			});
		}).start();
	}

	private void askPassword(String title, boolean confirm, final PasswordCallback callback) {
		final EditText first = passwordField("Password");
		final EditText second = confirm ? passwordField("Repeat password") : null;
		LinearLayout box = new LinearLayout(this);
		box.setOrientation(LinearLayout.VERTICAL);
		int pad = (int) (20 * getResources().getDisplayMetrics().density);
		box.setPadding(pad, pad / 2, pad, 0);
		box.addView(first);
		if (second != null) {
			box.addView(second);
		}
		new AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("Cancel", null).setPositiveButton("OK", (d, w) -> {
			if (first.length() == 0) {
				toast("Enter a password");
				return;
			}
			if (second != null && !first.getText().toString().equals(second.getText().toString())) {
				toast("The passwords are not the same");
				return;
			}
			if (second != null && first.length() < 8) {
				toast("Use at least 8 characters");
				return;
			}
			char[] password = new char[first.length()];
			first.getText().getChars(0, password.length, password, 0);
			callback.ok(password);
		}).show();
	}

	private EditText passwordField(String hint) {
		EditText field = new EditText(this);
		field.setHint(hint);
		field.setSingleLine(true);
		field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		return field;
	}

	private void toast(String text) {
		Toast.makeText(this, text, Toast.LENGTH_LONG).show();
	}
}
