package app.safegallery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VaultActivity extends Activity implements LockAware {

	private static final int REQ_IMPORT = 1;
	private static final int REQ_EXPORT = 2;

	private static final class Item {
		final boolean folder;
		final String key;
		final String name;
		final Index.Entry entry;

		Item(boolean folder, String key, String name, Index.Entry entry) {
			this.folder = folder;
			this.key = key;
			this.name = name;
			this.entry = entry;
		}
	}

	private Vault vault;
	private String folder = "";
	private final List<Item> items = new ArrayList<>();
	private final Set<String> selected = new HashSet<>();
	private GridView grid;
	private TextView status;
	private TextView empty;
	private ItemsAdapter adapter;
	private ActionMode actionMode;
	private LruCache<String, Bitmap> cache;
	private final ExecutorService thumbPool = Executors.newFixedThreadPool(2);
	private final ExecutorService worker = Executors.newSingleThreadExecutor();
	private List<Index.Entry> pendingExport;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		vault = Session.vault;
		if (vault == null) {
			startActivity(new Intent(this, MainActivity.class));
			finish();
			return;
		}
		if (Settings.blockScreenshots(this)) {
			getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
		}
		cache = new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8)) {
			@Override
			protected int sizeOf(String key, Bitmap value) {
				return value.getByteCount();
			}
		};

		LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setBackgroundColor(Color.BLACK);

		status = new TextView(this);
		status.setTextColor(Color.WHITE);
		status.setBackgroundColor(0xFF2E7D32);
		status.setPadding(24, 12, 24, 12);
		status.setVisibility(View.GONE);
		root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

		DisplayMetrics dm = getResources().getDisplayMetrics();
		grid = new GridView(this);
		grid.setNumColumns(Math.max(3, (int) (dm.widthPixels / (90 * dm.density))));
		int gap = Math.max(1, (int) dm.density);
		grid.setHorizontalSpacing(gap);
		grid.setVerticalSpacing(gap);
		grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
		adapter = new ItemsAdapter();
		grid.setAdapter(adapter);
		grid.setOnItemClickListener((parent, view, position, id) -> onItemClicked(items.get(position)));
		grid.setOnItemLongClickListener((parent, view, position, id) -> {
			toggle(items.get(position));
			return true;
		});

		android.widget.FrameLayout frame = new android.widget.FrameLayout(this);
		frame.addView(grid, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		empty = new TextView(this);
		empty.setText("Empty. Tap Import to add photos and videos.");
		empty.setTextColor(0xFF9E9E9E);
		empty.setGravity(android.view.Gravity.CENTER);
		empty.setVisibility(View.GONE);
		frame.addView(empty, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		root.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
		setContentView(root);
		refresh();
		Disguise.apply(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
		Disguise.apply(this);
		if (folder.isEmpty()) {
			setTitle(Disguise.name(this));
		}
		collectShared();
	}

	/** Takes in the files that were sent to this vault from other apps while it was locked. */
	private void collectShared() {
		final Vault v = vault;
		worker.execute(() -> {
			try {
				final int n = v.collectInbox();
				if (n > 0) {
					runOnUiThread(() -> {
						refresh();
						Toast.makeText(this, n + " file(s) received from other apps", Toast.LENGTH_LONG).show();
					});
				}
			} catch (IOException | RuntimeException ignored) {
				// tried again the next time
			}
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		thumbPool.shutdownNow();
		worker.shutdown();
	}

	// ----- listing -----

	private void refresh() {
		items.clear();
		for (String f : vault.foldersIn(folder)) {
			items.add(new Item(true, "d:" + f, Index.nameOf(f), null));
		}
		for (Index.Entry e : Vault.sortedNewestFirst(vault.entriesIn(folder))) {
			items.add(new Item(false, e.id, e.name, e));
		}
		Set<String> keys = new HashSet<>();
		for (Item it : items) {
			keys.add(it.key);
		}
		selected.retainAll(keys);
		setTitle(folder.isEmpty() ? Disguise.name(this) : folder);
		empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
		adapter.notifyDataSetChanged();
	}

	private final class ItemsAdapter extends BaseAdapter {
		@Override
		public int getCount() {
			return items.size();
		}

		@Override
		public Object getItem(int position) {
			return items.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			Tile tile = convertView instanceof Tile ? (Tile) convertView : new Tile(VaultActivity.this);
			Item item = items.get(position);
			boolean hasThumb = !item.folder && !item.entry.thumb.isEmpty();
			tile.bind(item.name, item.folder, item.folder ? "" : item.entry.mime, hasThumb, selected.contains(item.key));
			tile.setTag(item.key);
			if (hasThumb) {
				tile.imageView().setImageDrawable(null);
				Bitmap cached = cache.get(item.entry.id);
				if (cached != null) {
					tile.showThumbnail(cached);
				} else {
					loadThumbnail(tile, item.entry);
				}
			}
			return tile;
		}
	}

	private void loadThumbnail(final Tile tile, final Index.Entry entry) {
		thumbPool.execute(() -> {
			try {
				byte[] jpeg = vault.readThumbnail(entry);
				if (jpeg == null) {
					return;
				}
				final Bitmap bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
				if (bitmap == null) {
					return;
				}
				cache.put(entry.id, bitmap);
				runOnUiThread(() -> {
					if (entry.id.equals(tile.getTag())) {
						tile.showThumbnail(bitmap);
					}
				});
			} catch (IOException | RuntimeException ignored) {
				// the tile keeps showing nothing
			}
		});
	}

	// ----- clicking and selecting -----

	private void onItemClicked(Item item) {
		if (actionMode != null) {
			toggle(item);
		} else if (item.folder) {
			folder = item.key.substring(2);
			refresh();
		} else if (item.entry.mime.startsWith("image/") || (item.entry.mime.startsWith("video/") && !Settings.externalVideoPlayer(this))) {
			Intent intent = new Intent(this, ViewerActivity.class);
			intent.putExtra(ViewerActivity.EXTRA_FOLDER, folder);
			intent.putExtra(ViewerActivity.EXTRA_ID, item.entry.id);
			startActivity(intent);
		} else {
			open(item.entry);
		}
	}

	@Override
	public void onBackPressed() {
		if (actionMode != null) {
			actionMode.finish();
		} else if (!folder.isEmpty()) {
			folder = Index.parentOf(folder);
			refresh();
		} else {
			super.onBackPressed();
		}
	}

	private void toggle(Item item) {
		if (!selected.remove(item.key)) {
			selected.add(item.key);
		}
		if (selected.isEmpty()) {
			if (actionMode != null) {
				actionMode.finish();
			}
		} else {
			if (actionMode == null) {
				actionMode = startActionMode(actionCallback);
			}
			if (actionMode != null) {
				actionMode.setTitle(selected.size() + " selected");
			}
		}
		adapter.notifyDataSetChanged();
	}

	private final ActionMode.Callback actionCallback = new ActionMode.Callback() {
		@Override
		public boolean onCreateActionMode(ActionMode mode, Menu menu) {
			menu.add(0, 1, 0, "Delete").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
			menu.add(0, 2, 1, "Export").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
			menu.add(0, 3, 2, "Move").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
			menu.add(0, 4, 3, "Rename").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
			menu.add(0, 5, 4, "Select all").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
			menu.add(0, 6, 5, "Clear metadata").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
			return true;
		}

		@Override
		public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
			return false;
		}

		@Override
		public boolean onActionItemClicked(ActionMode mode, MenuItem menuItem) {
			switch (menuItem.getItemId()) {
				case 1:
					confirmDelete();
					return true;
				case 2:
					startExport();
					return true;
				case 3:
					chooseMoveTarget();
					return true;
				case 4:
					renameSelected();
					return true;
				case 6:
					clearSelected();
					return true;
				case 5:
					for (Item it : items) {
						selected.add(it.key);
					}
					mode.setTitle(selected.size() + " selected");
					adapter.notifyDataSetChanged();
					return true;
				default:
					return false;
			}
		}

		@Override
		public void onDestroyActionMode(ActionMode mode) {
			selected.clear();
			actionMode = null;
			adapter.notifyDataSetChanged();
		}
	};

	private List<Index.Entry> selectedEntries() {
		List<Index.Entry> result = new ArrayList<>();
		for (Item it : items) {
			if (!it.folder && selected.contains(it.key)) {
				result.add(it.entry);
			}
		}
		return result;
	}

	private List<String> selectedFolders() {
		List<String> result = new ArrayList<>();
		for (Item it : items) {
			if (it.folder && selected.contains(it.key)) {
				result.add(it.key.substring(2));
			}
		}
		return result;
	}

	private void finishSelection() {
		if (actionMode != null) {
			actionMode.finish();
		}
	}

	// ----- menu -----

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 10, 0, "Import").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		menu.add(0, 11, 1, "New folder").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		menu.add(0, 13, 2, "Settings").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		menu.add(0, 12, 3, "Lock").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case 10:
				startImport();
				return true;
			case 11:
				newFolder();
				return true;
			case 13:
				startActivity(new Intent(this, SettingsActivity.class));
				return true;
			case 12:
				App.lock();
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}

	// ----- opening -----

	private void open(Index.Entry entry) {
		Uri uri = new Uri.Builder().scheme("content").authority(VaultProvider.AUTH).appendPath("f").appendPath(entry.id).appendPath(entry.name).build();
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setDataAndType(uri, entry.mime.isEmpty() ? "*/*" : entry.mime);
		intent.setClipData(ClipData.newRawUri("", uri));
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		// no chooser is forced: Android itself asks "Just once / Always" when it has no default app for this kind of file
		App.suppressLeave();
		try {
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			toast("No app can open this kind of file");
		}
	}

	// ----- folders -----

	private void newFolder() {
		final EditText input = new EditText(this);
		input.setSingleLine(true);
		new AlertDialog.Builder(this).setTitle("New folder").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create", (d, w) -> {
			String name = input.getText().toString().trim().replace("/", "");
			if (name.isEmpty()) {
				return;
			}
			final String path = folder.isEmpty() ? name : folder + "/" + name;
			worker.execute(() -> {
				try {
					vault.createFolder(path);
				} catch (IOException e) {
					toast("Failed: " + e.getMessage());
				}
				runOnUiThread(this::refresh);
			});
		}).show();
	}

	private void renameSelected() {
		final List<Index.Entry> files = selectedEntries();
		if (files.size() != 1 || !selectedFolders().isEmpty()) {
			toast("Select one file to rename it");
			return;
		}
		final Index.Entry entry = files.get(0);
		final EditText input = new EditText(this);
		input.setText(entry.name);
		new AlertDialog.Builder(this).setTitle("Rename").setView(input).setNegativeButton("Cancel", null).setPositiveButton("OK", (d, w) -> {
			final String name = input.getText().toString().trim();
			if (name.isEmpty()) {
				return;
			}
			worker.execute(() -> {
				try {
					vault.rename(entry, name);
				} catch (IOException e) {
					toast("Failed: " + e.getMessage());
				}
				runOnUiThread(() -> {
					finishSelection();
					refresh();
				});
			});
		}).show();
	}

	private void chooseMoveTarget() {
		final List<Index.Entry> files = selectedEntries();
		if (files.isEmpty()) {
			toast("Select files to move");
			return;
		}
		final List<String> targets = new ArrayList<>();
		targets.add("");
		List<String> all = vault.allFolders();
		Collections.sort(all);
		targets.addAll(all);
		String[] labels = new String[targets.size()];
		for (int i = 0; i < labels.length; i++) {
			labels[i] = targets.get(i).isEmpty() ? "Main folder" : targets.get(i);
		}
		new AlertDialog.Builder(this).setTitle("Move to").setItems(labels, (d, which) -> {
			final String target = targets.get(which);
			worker.execute(() -> {
				try {
					vault.move(files, target);
				} catch (IOException e) {
					toast("Failed: " + e.getMessage());
				}
				runOnUiThread(() -> {
					finishSelection();
					refresh();
				});
			});
		}).show();
	}

	private void confirmDelete() {
		final List<Index.Entry> files = selectedEntries();
		final List<String> folders = selectedFolders();
		new AlertDialog.Builder(this).setTitle("Delete").setMessage("Delete " + files.size() + " file(s) and " + folders.size() + " folder(s) with everything in them? This can't be undone.").setNegativeButton("Cancel", null).setPositiveButton("Delete", (d, w) -> {
			worker.execute(() -> {
				try {
					vault.delete(files);
					for (String f : folders) {
						vault.deleteFolder(f);
					}
				} catch (IOException e) {
					toast("Failed: " + e.getMessage());
				}
				runOnUiThread(() -> {
					finishSelection();
					refresh();
				});
			});
		}).show();
	}

	// ----- import -----

	private void startImport() {
		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
		intent.addCategory(Intent.CATEGORY_OPENABLE);
		intent.setType("*/*");
		intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		App.suppressLeave();
		startActivityForResult(intent, REQ_IMPORT);
	}

	private void startExport() {
		pendingExport = selectedEntries();
		if (pendingExport.isEmpty()) {
			toast("Select files to export");
			return;
		}
		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		App.suppressLeave();
		startActivityForResult(intent, REQ_EXPORT);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != RESULT_OK || data == null) {
			return;
		}
		if (requestCode == REQ_IMPORT) {
			final List<Uri> uris = new ArrayList<>();
			if (data.getClipData() != null) {
				for (int i = 0; i < data.getClipData().getItemCount(); i++) {
					uris.add(data.getClipData().getItemAt(i).getUri());
				}
			} else if (data.getData() != null) {
				uris.add(data.getData());
			}
			if (uris.isEmpty()) {
				return;
			}
			new AlertDialog.Builder(this).setTitle("Import " + uris.size() + " file(s)").setMessage("Delete the originals after they are encrypted?").setPositiveButton("Import and delete originals", (d, w) -> runImport(uris, true)).setNegativeButton("Import only", (d, w) -> runImport(uris, false)).setNeutralButton("Cancel", null).show();
		} else if (requestCode == REQ_EXPORT && data.getData() != null && pendingExport != null) {
			runExport(data.getData(), pendingExport);
			pendingExport = null;
			finishSelection();
		}
	}

	private void runImport(final List<Uri> uris, final boolean deleteOriginals) {
		final String target = folder;
		final boolean clean = Settings.autoClean(this);
		worker.execute(() -> {
			int ok = 0;
			int failed = 0;
			int notDeleted = 0;
			int notCleaned = 0;
			for (int i = 0; i < uris.size(); i++) {
				setStatus((clean ? "Cleaning and importing " : "Importing ") + (i + 1) + " of " + uris.size() + "…");
				Uri uri = uris.get(i);
				try {
					boolean cleaned = Importer.addToVault(this, vault, uri, target, clean);
					ok++;
					if (clean && !cleaned) {
						notCleaned++;
					}
					if (deleteOriginals) {
						try {
							if (!DocumentsContract.deleteDocument(getContentResolver(), uri)) {
								notDeleted++;
							}
						} catch (Exception e) {
							notDeleted++;
						}
					}
				} catch (Exception e) {
					failed++;
				}
				if (i % 5 == 4) {
					runOnUiThread(this::refresh);
				}
			}
			setStatus(null);
			toast("Imported " + ok + (failed > 0 ? ", failed " + failed : "") + (notDeleted > 0 ? ", could not delete " + notDeleted + " original(s)" : "") + (notCleaned > 0 ? ", " + notCleaned + " could not be cleaned" : ""));
			runOnUiThread(this::refresh);
		});
	}

	private void clearSelected() {
		final List<Index.Entry> files = selectedEntries();
		if (files.isEmpty()) {
			toast("Select photos or videos to clear");
			return;
		}
		finishSelection();
		worker.execute(() -> {
			int done = 0;
			int skipped = 0;
			int failed = 0;
			for (int i = 0; i < files.size(); i++) {
				setStatus("Clearing " + (i + 1) + " of " + files.size() + "…");
				Index.Entry e = files.get(i);
				try (Crypto.Reader reader = vault.openReader(e); MediaCleaner.Cleaned c = MediaCleaner.open(new ReaderStream(reader, false), true)) {
					if (!c.changed) {
						skipped++;
						continue;
					}
					// the cleaned copy is made first and the old file is removed only when the copy is complete
					Index.Entry fresh = vault.addFile(c.stream, e.name, e.mime, e.folder, vault.readThumbnail(e));
					try {
						c.check();
					} catch (IOException bad) {
						List<Index.Entry> broken = new ArrayList<>();
						broken.add(fresh);
						vault.delete(broken);
						throw bad;
					}
					List<Index.Entry> old = new ArrayList<>();
					old.add(e);
					vault.delete(old);
					done++;
				} catch (Exception ex) {
					failed++;
				}
			}
			setStatus(null);
			toast("Cleared " + done + (skipped > 0 ? ", " + skipped + " can't be cleaned" : "") + (failed > 0 ? ", failed " + failed : ""));
			runOnUiThread(this::refresh);
		});
	}

	private void runExport(final Uri tree, final List<Index.Entry> files) {
		worker.execute(() -> {
			int ok = 0;
			Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
			for (int i = 0; i < files.size(); i++) {
				setStatus("Exporting " + (i + 1) + " of " + files.size() + "…");
				Index.Entry e = files.get(i);
				try {
					Uri dest = DocumentsContract.createDocument(getContentResolver(), parent, e.mime, e.name);
					if (dest == null) {
						throw new IOException("Could not create " + e.name);
					}
					try (OutputStream out = getContentResolver().openOutputStream(dest)) {
						vault.export(e, out);
					}
					ok++;
				} catch (Exception ex) {
					// counted as failed
				}
			}
			setStatus(null);
			toast("Exported " + ok + " of " + files.size());
		});
	}

	// ----- small helpers -----

	private void setStatus(final String text) {
		runOnUiThread(() -> {
			if (text == null) {
				status.setVisibility(View.GONE);
			} else {
				status.setText(text);
				status.setVisibility(View.VISIBLE);
			}
		});
	}

	private void toast(final String text) {
		runOnUiThread(() -> Toast.makeText(VaultActivity.this, text, Toast.LENGTH_LONG).show());
	}
}
