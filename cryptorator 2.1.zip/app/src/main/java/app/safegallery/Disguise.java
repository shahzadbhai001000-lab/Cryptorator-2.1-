package app.safegallery;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;

/**
 * Switches the app icon and the name under the icon between Cryptorator and Gboard. The name that Android's settings
 * app shows in its list of apps comes from the app itself and cannot be changed while the app is installed, so it is
 * always "Gboard".
 */
final class Disguise {

	static final String NORMAL_NAME = "Cryptorator";
	static final String DISGUISE_NAME = "Gboard";
	private static final String ALIAS_NORMAL = "app.safegallery.AliasNormal";
	private static final String ALIAS_DISGUISE = "app.safegallery.AliasGboard";

	private Disguise() {
	}

	static boolean isDisguised(Context context) {
		return context.getPackageManager().getComponentEnabledSetting(new ComponentName(context.getPackageName(), ALIAS_DISGUISE)) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED;
	}

	static String name(Context context) {
		return isDisguised(context) ? DISGUISE_NAME : NORMAL_NAME;
	}

	static void set(Context context, boolean disguised) {
		PackageManager pm = context.getPackageManager();
		ComponentName normal = new ComponentName(context.getPackageName(), ALIAS_NORMAL);
		ComponentName other = new ComponentName(context.getPackageName(), ALIAS_DISGUISE);
		// the new one is switched on first, so that the app never has no icon
		if (disguised) {
			pm.setComponentEnabledSetting(other, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
			pm.setComponentEnabledSetting(normal, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
		} else {
			pm.setComponentEnabledSetting(normal, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
			pm.setComponentEnabledSetting(other, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
		}
	}

	/** Shows the current name in the title bar and in the list of recent apps. */
	@SuppressWarnings("deprecation")
	static void apply(Activity activity) {
		String name = name(activity);
		activity.setTitle(name);
		activity.setTaskDescription(new ActivityManager.TaskDescription(name));
	}
}
