package app.safegallery;

import android.media.MediaDataSource;

import java.io.IOException;

/** Lets the system's media player read a video straight from the encrypted file, decrypting as it goes. */
final class VaultMediaSource extends MediaDataSource {

	private final Crypto.Reader reader;

	VaultMediaSource(Crypto.Reader reader) {
		this.reader = reader;
	}

	@Override
	public int readAt(long position, byte[] buffer, int offset, int size) throws IOException {
		if (size == 0) {
			return 0;
		}
		return reader.read(position, buffer, offset, size);
	}

	@Override
	public long getSize() {
		return reader.size();
	}

	@Override
	public void close() throws IOException {
		reader.close();
	}
}
