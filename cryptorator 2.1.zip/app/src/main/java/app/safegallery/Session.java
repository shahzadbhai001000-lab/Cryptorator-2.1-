package app.safegallery;

import android.net.Uri;

/** The vault that is unlocked right now. It only lives in memory. */
final class Session {

	static volatile Vault vault;
	static volatile Uri tree;

	private Session() {
	}

	static void unlocked(Vault v, Uri treeUri) {
		tree = treeUri;
		vault = v;
		App.touch();
	}

	static boolean isUnlocked(Uri treeUri) {
		return vault != null && tree != null && tree.equals(treeUri);
	}

	static void lock() {
		vault = null;
		tree = null;
	}
}
