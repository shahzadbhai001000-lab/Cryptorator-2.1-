package app.safegallery;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;

/**
 * A video played by the system's media player straight from the encrypted file. Only the page in front has a player.
 * If the player fails while playing, it is started again at the place where it stopped.
 */
final class VideoPage extends SwipePager.Page implements TextureView.SurfaceTextureListener {

	interface Host {
		void onTap();

		void openElsewhere(Index.Entry entry);
	}

	private final Vault vault;
	private final Index.Entry entry;
	private final ExecutorService pool;
	private final Host host;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final ImageView thumb;
	private final ProgressBar spinner;
	private final TextView message;
	private final LinearLayout controls;
	private final TextView playButton;
	private final TextView timeView;
	private final SeekBar seek;
	private TextureView texture;
	private Surface surface;
	private MediaPlayer player;
	private Crypto.Reader reader;
	private int generation;
	private boolean active;
	private boolean prepared;
	private boolean wantPlay = true;
	private boolean ended;
	private boolean userSeeking;
	private boolean released;
	private int resumeAt;
	private int videoW;
	private int videoH;
	private int restarts;
	private boolean chrome = true;

	private final Runnable ticker = new Runnable() {
		@Override
		public void run() {
			update();
			ui.postDelayed(this, 400);
		}
	};

	VideoPage(Context context, Vault vault, Index.Entry entry, ExecutorService pool, Host host) {
		super(context);
		this.vault = vault;
		this.entry = entry;
		this.pool = pool;
		this.host = host;
		setBackgroundColor(Color.BLACK);
		float d = context.getResources().getDisplayMetrics().density;

		thumb = new ImageView(context);
		thumb.setScaleType(ImageView.ScaleType.FIT_CENTER);
		addView(thumb, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

		spinner = new ProgressBar(context);
		addView(spinner, new LayoutParams((int) (48 * d), (int) (48 * d), Gravity.CENTER));
		spinner.setVisibility(GONE);

		message = new TextView(context);
		message.setTextColor(0xFFE0E0E0);
		message.setGravity(Gravity.CENTER);
		message.setPadding((int) (24 * d), 0, (int) (24 * d), 0);
		message.setVisibility(GONE);
		message.setOnClickListener(v -> host.openElsewhere(entry));
		addView(message, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

		controls = new LinearLayout(context);
		controls.setOrientation(LinearLayout.HORIZONTAL);
		controls.setGravity(Gravity.CENTER_VERTICAL);
		controls.setBackgroundColor(0x99000000);
		int pad = (int) (8 * d);
		controls.setPadding(pad, pad, pad, pad);
		playButton = new TextView(context);
		playButton.setTextColor(Color.WHITE);
		playButton.setTextSize(26);
		playButton.setGravity(Gravity.CENTER);
		playButton.setText("▶");
		playButton.setOnClickListener(v -> togglePlay());
		controls.addView(playButton, new LinearLayout.LayoutParams((int) (48 * d), (int) (48 * d)));
		seek = new SeekBar(context);
		seek.setMax(1000);
		seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
				if (fromUser && player != null && prepared) {
					timeView.setText(format(progress * player.getDuration() / 1000) + " / " + format(player.getDuration()));
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar s) {
				userSeeking = true;
			}

			@Override
			public void onStopTrackingTouch(SeekBar s) {
				userSeeking = false;
				if (player != null && prepared) {
					int to = (int) ((long) s.getProgress() * player.getDuration() / 1000);
					ended = false;
					player.seekTo(to, MediaPlayer.SEEK_CLOSEST_SYNC);
					resumeAt = to;
				}
			}
		});
		controls.addView(seek, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		timeView = new TextView(context);
		timeView.setTextColor(Color.WHITE);
		timeView.setTextSize(12);
		timeView.setPadding(pad, 0, pad, 0);
		timeView.setText("0:00 / 0:00");
		controls.addView(timeView);
		addView(controls, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

		setOnClickListener(v -> host.onTap());
		loadThumbnail();
	}

	private void loadThumbnail() {
		if (entry.thumb.isEmpty()) {
			return;
		}
		pool.execute(() -> {
			try {
				byte[] jpeg = vault.readThumbnail(entry);
				final Bitmap b = jpeg == null ? null : BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
				if (b != null) {
					post(() -> {
						if (!released) {
							thumb.setImageBitmap(b);
						}
					});
				}
			} catch (IOException | RuntimeException ignored) {
				// no preview
			}
		});
	}

	private static String format(long ms) {
		long s = Math.max(0, ms) / 1000;
		return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
	}

	// ----- showing and hiding -----

	@Override
	void setChromeVisible(boolean visible) {
		chrome = visible;
		controls.setVisibility(visible ? VISIBLE : GONE);
	}

	@Override
	void activate() {
		if (active || released) {
			return;
		}
		active = true;
		ended = false;
		message.setVisibility(GONE);
		spinner.setVisibility(VISIBLE);
		texture = new TextureView(getContext());
		texture.setSurfaceTextureListener(this);
		texture.setOnClickListener(v -> host.onTap());
		addView(texture, 0, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		ui.post(ticker);
	}

	@Override
	void deactivate() {
		if (!active) {
			return;
		}
		active = false;
		ui.removeCallbacks(ticker);
		stopPlayer();
		if (texture != null) {
			removeView(texture);
			texture.setSurfaceTextureListener(null);
			texture = null;
		}
		if (surface != null) {
			surface.release();
			surface = null;
		}
		thumb.setVisibility(VISIBLE);
		spinner.setVisibility(GONE);
		resumeAt = 0;
		wantPlay = true;
		playButton.setText("▶");
	}

	@Override
	void pause() {
		if (player != null && prepared) {
			try {
				if (player.isPlaying()) {
					player.pause();
				}
				resumeAt = player.getCurrentPosition();
			} catch (IllegalStateException ignored) {
				// already gone
			}
			wantPlay = false;
			playButton.setText("▶");
		}
	}

	@Override
	void release() {
		released = true;
		deactivate();
	}

	// ----- surface -----

	@Override
	public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
		if (surface != null) {
			surface.release();
		}
		surface = new Surface(st);
		if (player != null) {
			player.setSurface(surface);
		} else {
			startPlayer();
		}
		fitVideo();
	}

	@Override
	public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
		fitVideo();
	}

	@Override
	public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
		if (player != null) {
			try {
				player.setSurface(null);
			} catch (IllegalStateException ignored) {
				// already gone
			}
		}
		if (surface != null) {
			surface.release();
			surface = null;
		}
		return true;
	}

	@Override
	public void onSurfaceTextureUpdated(SurfaceTexture st) {
	}

	private void fitVideo() {
		if (texture == null || videoW <= 0 || videoH <= 0 || texture.getWidth() <= 0) {
			return;
		}
		float vw = texture.getWidth();
		float vh = texture.getHeight();
		float scale = Math.min(vw / videoW, vh / videoH);
		Matrix m = new Matrix();
		m.setScale(videoW * scale / vw, videoH * scale / vh, vw / 2f, vh / 2f);
		texture.setTransform(m);
	}

	// ----- player -----

	private void startPlayer() {
		final int gen = ++generation;
		prepared = false;
		spinner.setVisibility(VISIBLE);
		pool.execute(() -> {
			final Crypto.Reader r;
			try {
				r = vault.openReader(entry);
			} catch (IOException e) {
				post(() -> fail(gen, "Can't read this video"));
				return;
			}
			post(() -> {
				if (gen != generation || !active || released || surface == null) {
					try {
						r.close();
					} catch (IOException ignored) {
						// closed
					}
					return;
				}
				reader = r;
				MediaPlayer p = new MediaPlayer();
				player = p;
				try {
					p.setDataSource(new VaultMediaSource(r));
					p.setSurface(surface);
					p.setOnVideoSizeChangedListener((mp, w, h) -> {
						videoW = w;
						videoH = h;
						fitVideo();
					});
					p.setOnPreparedListener(mp -> {
						if (gen != generation) {
							return;
						}
						prepared = true;
						spinner.setVisibility(GONE);
						thumb.setVisibility(GONE);
						if (resumeAt > 0) {
							mp.seekTo(resumeAt, MediaPlayer.SEEK_CLOSEST_SYNC);
						}
						if (wantPlay && active) {
							mp.start();
							playButton.setText("⏸");
						}
						update();
					});
					p.setOnInfoListener((mp, what, extra) -> {
						if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
							spinner.setVisibility(VISIBLE);
						} else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END || what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
							spinner.setVisibility(GONE);
						}
						return false;
					});
					p.setOnCompletionListener(mp -> {
						ended = true;
						wantPlay = false;
						resumeAt = 0;
						playButton.setText("▶");
						seek.setProgress(seek.getMax());
					});
					p.setOnErrorListener((mp, what, extra) -> {
						if (gen != generation) {
							return true;
						}
						// restart once or twice from where it stopped, then give up with a message
						if (restarts < 2 && active && !released) {
							restarts++;
							stopPlayer();
							startPlayer();
						} else {
							fail(gen, "This video can't be played here. Tap to open it with another app.");
						}
						return true;
					});
					p.prepareAsync();
				} catch (RuntimeException e) {
					fail(gen, "Can't play this video. Tap to open it with another app.");
				}
			});
		});
	}

	private void stopPlayer() {
		generation++;
		MediaPlayer p = player;
		player = null;
		if (p != null) {
			if (prepared) {
				try {
					resumeAt = p.getCurrentPosition();
				} catch (IllegalStateException ignored) {
					// keep the old place
				}
			}
			prepared = false;
			try {
				p.setOnErrorListener(null);
				p.setOnCompletionListener(null);
				p.reset();
			} catch (RuntimeException ignored) {
				// being released anyway
			}
			p.release();
		}
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException ignored) {
				// closed
			}
			reader = null;
		}
	}

	private void fail(int gen, String text) {
		if (gen != generation && !text.startsWith("Can't read")) {
			return;
		}
		spinner.setVisibility(GONE);
		message.setText(text);
		message.setVisibility(VISIBLE);
	}

	private void togglePlay() {
		if (player == null || !prepared) {
			return;
		}
		try {
			if (player.isPlaying()) {
				player.pause();
				wantPlay = false;
				playButton.setText("▶");
			} else {
				if (ended) {
					ended = false;
					player.seekTo(0, MediaPlayer.SEEK_CLOSEST_SYNC);
				}
				player.start();
				wantPlay = true;
				playButton.setText("⏸");
			}
		} catch (IllegalStateException e) {
			// the player is being replaced
		}
	}

	private void update() {
		if (player == null || !prepared || userSeeking) {
			return;
		}
		try {
			int duration = player.getDuration();
			int pos = player.getCurrentPosition();
			if (duration > 0) {
				seek.setProgress((int) ((long) pos * 1000 / duration));
				timeView.setText(format(pos) + " / " + format(duration));
			}
			if (player.isPlaying()) {
				resumeAt = pos;
				restarts = 0;
			}
		} catch (IllegalStateException ignored) {
			// the player is being replaced
		}
	}
}
