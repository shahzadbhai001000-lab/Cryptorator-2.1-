package app.safegallery;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;

/** A photo or GIF. The small picture shows at once, the full picture replaces it when it is decrypted. */
final class ImagePage extends SwipePager.Page {

	private static final int MAX_BYTES = 120 * 1024 * 1024;
	private static final int MAX_SIDE = 2400;

	private final Vault vault;
	private final Index.Entry entry;
	private final ExecutorService pool;
	private final ZoomImageView image;
	private final TextView message;
	private volatile boolean active;
	private volatile boolean released;
	private boolean fullLoaded;
	private boolean loading;

	ImagePage(android.content.Context context, Vault vault, Index.Entry entry, ExecutorService pool, Runnable onTap) {
		super(context);
		this.vault = vault;
		this.entry = entry;
		this.pool = pool;
		setBackgroundColor(Color.BLACK);
		image = new ZoomImageView(context);
		image.setOnTap(onTap);
		addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		message = new TextView(context);
		message.setTextColor(0xFFBDBDBD);
		message.setGravity(Gravity.CENTER);
		message.setVisibility(GONE);
		addView(message, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
		loadThumbnail();
	}

	private void loadThumbnail() {
		if (entry.thumb.isEmpty()) {
			return;
		}
		pool.execute(() -> {
			try {
				byte[] jpeg = vault.readThumbnail(entry);
				final Bitmap b = jpeg == null ? null : BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
				if (b != null) {
					post(() -> {
						if (!fullLoaded && !released) {
							image.setImageBitmap(b);
						}
					});
				}
			} catch (IOException | RuntimeException ignored) {
				// the full picture will follow
			}
		});
	}

	@Override
	void activate() {
		active = true;
		if (fullLoaded || loading) {
			Drawable d = image.getDrawable();
			if (d instanceof AnimatedImageDrawable) {
				((AnimatedImageDrawable) d).start();
			}
			return;
		}
		loading = true;
		pool.execute(() -> {
			Drawable result = null;
			String error = null;
			try {
				result = decode();
			} catch (OutOfMemoryError e) {
				error = "This picture is too big to show";
			} catch (Exception e) {
				error = "Can't show this picture";
			}
			final Drawable drawable = result;
			final String err = error;
			post(() -> {
				loading = false;
				if (released) {
					return;
				}
				if (drawable != null) {
					fullLoaded = true;
					image.setImageDrawable(drawable);
					if (drawable instanceof AnimatedImageDrawable && active) {
						((AnimatedImageDrawable) drawable).start();
					}
				} else if (image.getDrawable() == null) {
					message.setText(err);
					message.setVisibility(VISIBLE);
				}
			});
		});
	}

	private Drawable decode() throws IOException {
		byte[] data;
		try (Crypto.Reader reader = vault.openReader(entry)) {
			long size = reader.size();
			if (size > MAX_BYTES) {
				throw new IOException("too big");
			}
			data = new byte[(int) size];
			int done = 0;
			while (done < data.length) {
				int n = reader.read(done, data, done, data.length - done);
				if (n <= 0) {
					throw new IOException("short");
				}
				done += n;
			}
		}
		if (released) {
			return null;
		}
		ImageDecoder.Source source = ImageDecoder.createSource(ByteBuffer.wrap(data));
		return ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
			int side = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
			int sample = 1;
			while (side / (sample * 2) >= MAX_SIDE) {
				sample *= 2;
			}
			if (sample > 1) {
				decoder.setTargetSampleSize(sample);
			}
		});
	}

	@Override
	void deactivate() {
		active = false;
		Drawable d = image.getDrawable();
		if (d instanceof AnimatedImageDrawable) {
			((AnimatedImageDrawable) d).stop();
		}
	}

	@Override
	void pause() {
		deactivate();
	}

	@Override
	void release() {
		released = true;
		active = false;
		Drawable d = image.getDrawable();
		if (d instanceof AnimatedImageDrawable) {
			((AnimatedImageDrawable) d).stop();
		}
		image.setImageDrawable(null);
	}

	@Override
	boolean canPan(int direction) {
		return image.canPan(direction);
	}
}
