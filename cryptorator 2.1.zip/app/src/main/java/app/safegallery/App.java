package app.safegallery;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

/** Decides when the vault locks: when the app is left, when the screen goes off, when the phone is shaken. */
public class App extends Application implements Application.ActivityLifecycleCallbacks, SensorEventListener {

	private static App instance;

	private final Handler handler = new Handler(Looper.getMainLooper());
	private final List<Activity> vaultScreens = new ArrayList<>();
	private int started;
	private long leftAt;
	private boolean external;
	private boolean listening;
	private long firstShake;
	private long lastShake;
	private int shakes;

	private final Runnable lockLater = this::lockNow;

	@Override
	public void onCreate() {
		super.onCreate();
		instance = this;
		registerActivityLifecycleCallbacks(this);
		IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		BroadcastReceiver receiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				if (Settings.lockOnScreenOff(App.this)) {
					lockNow();
				}
			}
		};
		if (Build.VERSION.SDK_INT >= 33) {
			registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
		} else {
			registerReceiver(receiver, filter);
		}
	}

	/** Call right before starting another app (the file picker, a video player...), so that leaving does not lock. */
	static void suppressLeave() {
		if (instance != null) {
			instance.external = true;
		}
	}

	/** Call after the vault was unlocked or a setting changed. */
	static void touch() {
		if (instance != null) {
			instance.handler.post(instance::updateShake);
		}
	}

	static void lock() {
		if (instance != null) {
			instance.handler.post(instance::lockNow);
		} else {
			Session.lock();
		}
	}

	private void lockNow() {
		handler.removeCallbacks(lockLater);
		boolean wasOpen = Session.vault != null;
		Session.lock();
		updateShake();
		for (Activity a : new ArrayList<>(vaultScreens)) {
			a.finish();
		}
		vaultScreens.clear();
		if (wasOpen && started > 0) {
			Intent intent = new Intent(this, MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
		}
	}

	// ----- shake -----

	private void updateShake() {
		SensorManager sensors = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		if (sensors == null) {
			return;
		}
		boolean want = started > 0 && Session.vault != null && Settings.lockOnShake(this);
		if (want && !listening) {
			Sensor accel = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
			if (accel != null) {
				sensors.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
				listening = true;
				shakes = 0;
			}
		} else if (!want && listening) {
			sensors.unregisterListener(this);
			listening = false;
		}
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		float g = (float) Math.sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]) / SensorManager.GRAVITY_EARTH;
		int level = Settings.shakeSensitivity(this);
		float threshold = level == 0 ? 2.8f : level == 1 ? 2.2f : 1.7f;
		if (g < threshold) {
			return;
		}
		long now = SystemClock.elapsedRealtime();
		if (now - firstShake > 900) {
			firstShake = now;
			shakes = 1;
		} else if (now - lastShake > 120) {
			shakes++;
		}
		lastShake = now;
		if (shakes >= 3) {
			shakes = 0;
			lockNow();
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
	}

	// ----- leaving and coming back -----

	@Override
	public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
		if (activity instanceof LockAware) {
			vaultScreens.add(activity);
		}
	}

	@Override
	public void onActivityDestroyed(Activity activity) {
		vaultScreens.remove(activity);
	}

	@Override
	public void onActivityStarted(Activity activity) {
		started++;
		if (started == 1) {
			handler.removeCallbacks(lockLater);
			long delay = Settings.lockDelay(this);
			if (Session.vault != null && leftAt != 0 && delay >= 0 && SystemClock.elapsedRealtime() - leftAt >= delay) {
				leftAt = 0;
				lockNow();
				return;
			}
			leftAt = 0;
		}
		updateShake();
	}

	@Override
	public void onActivityStopped(Activity activity) {
		started--;
		if (started > 0) {
			return;
		}
		started = 0;
		updateShake();
		if (activity.isChangingConfigurations()) {
			return;
		}
		if (external) {
			external = false;
			leftAt = 0;
			return;
		}
		if (Session.vault == null) {
			return;
		}
		long delay = Settings.lockDelay(this);
		leftAt = SystemClock.elapsedRealtime();
		if (delay == 0) {
			lockNow();
		} else if (delay > 0) {
			handler.postDelayed(lockLater, delay);
		}
	}

	@Override
	public void onActivityResumed(Activity activity) {
		external = false;
	}

	@Override
	public void onActivityPaused(Activity activity) {
	}

	@Override
	public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
	}
}
