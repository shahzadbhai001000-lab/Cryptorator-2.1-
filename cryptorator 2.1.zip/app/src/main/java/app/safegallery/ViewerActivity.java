package app.safegallery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Shows the photos and videos of a folder one by one. Swipe sideways to go to the next or the one before. */
public class ViewerActivity extends Activity implements LockAware {

	static final String EXTRA_FOLDER = "folder";
	static final String EXTRA_ID = "id";

	private Vault vault;
	private final List<Index.Entry> files = new ArrayList<>();
	private SwipePager pager;
	private TextView title;
	private View bar;
	private boolean chrome = true;
	private ExecutorService pool;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		vault = Session.vault;
		if (vault == null) {
			finish();
			return;
		}
		if (Settings.blockScreenshots(this)) {
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		}
		String folder = getIntent().getStringExtra(EXTRA_FOLDER);
		String id = getIntent().getStringExtra(EXTRA_ID);
		int start = 0;
		for (Index.Entry e : Vault.sortedNewestFirst(vault.entriesIn(folder == null ? "" : folder))) {
			if (e.mime.startsWith("image/") || e.mime.startsWith("video/")) {
				if (e.id.equals(id)) {
					start = files.size();
				}
				files.add(e);
			}
		}
		pool = Executors.newFixedThreadPool(2);

		FrameLayout root = new FrameLayout(this);
		root.setBackgroundColor(Color.BLACK);
		pager = new SwipePager(this);
		root.addView(pager, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

		float d = getResources().getDisplayMetrics().density;
		LinearLayout top = new LinearLayout(this);
		top.setOrientation(LinearLayout.HORIZONTAL);
		top.setGravity(Gravity.CENTER_VERTICAL);
		top.setBackgroundColor(0x99000000);
		int pad = (int) (12 * d);
		top.setPadding(pad, pad, pad, pad);
		TextView back = new TextView(this);
		back.setText("←");
		back.setTextColor(Color.WHITE);
		back.setTextSize(24);
		back.setPadding(0, 0, pad, 0);
		back.setOnClickListener(v -> finish());
		top.addView(back);
		title = new TextView(this);
		title.setTextColor(Color.WHITE);
		title.setTextSize(15);
		title.setSingleLine(true);
		title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
		top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		TextView more = new TextView(this);
		more.setText("⋮");
		more.setTextColor(Color.WHITE);
		more.setTextSize(24);
		more.setPadding(pad, 0, pad / 2, 0);
		more.setOnClickListener(v -> showMenu());
		top.addView(more);
		bar = top;
		root.addView(top, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
		setContentView(root);

		pager.setListener(position -> {
			if (position < 0) {
				finish();
				return;
			}
			title.setText((position + 1) + " / " + files.size() + "   " + files.get(position).name);
		});
		pager.setAdapter(new SwipePager.Adapter() {
			@Override
			public int count() {
				return files.size();
			}

			@Override
			public SwipePager.Page create(int position) {
				return makePage(files.get(position));
			}
		}, start);
		if (files.isEmpty()) {
			finish();
		}
	}

	private SwipePager.Page makePage(final Index.Entry entry) {
		if (entry.mime.startsWith("video/")) {
			return new VideoPage(this, vault, entry, pool, new VideoPage.Host() {
				@Override
				public void onTap() {
					toggleChrome();
				}

				@Override
				public void openElsewhere(Index.Entry e) {
					openWith(e);
				}
			});
		}
		return new ImagePage(this, vault, entry, pool, this::toggleChrome);
	}

	private void toggleChrome() {
		chrome = !chrome;
		bar.setVisibility(chrome ? View.VISIBLE : View.GONE);
		pager.setChromeVisible(chrome);
		int flags = chrome ? View.SYSTEM_UI_FLAG_VISIBLE : View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
		getWindow().getDecorView().setSystemUiVisibility(flags);
	}

	private void showMenu() {
		new AlertDialog.Builder(this).setItems(new String[]{"Open with…", "Delete"}, (dialog, which) -> {
			int position = pager.position();
			if (position < 0 || position >= files.size()) {
				return;
			}
			if (which == 0) {
				openWith(files.get(position));
			} else {
				confirmDelete(position);
			}
		}).show();
	}

	private void confirmDelete(final int position) {
		final Index.Entry entry = files.get(position);
		new AlertDialog.Builder(this).setTitle("Delete").setMessage("Delete \"" + entry.name + "\" from the vault? This can't be undone.").setNegativeButton("Cancel", null).setPositiveButton("Delete", (d, w) -> {
			pager.pauseAll();
			pool.execute(() -> {
				try {
					List<Index.Entry> one = new ArrayList<>();
					one.add(entry);
					vault.delete(one);
					runOnUiThread(() -> {
						files.remove(entry);
						if (files.isEmpty()) {
							finish();
						} else {
							pager.reload(Math.min(position, files.size() - 1));
						}
					});
				} catch (IOException e) {
					runOnUiThread(() -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
				}
			});
		}).show();
	}

	private void openWith(Index.Entry entry) {
		Uri uri = new Uri.Builder().scheme("content").authority(VaultProvider.AUTH).appendPath("f").appendPath(entry.id).appendPath(entry.name).build();
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setDataAndType(uri, entry.mime.isEmpty() ? "*/*" : entry.mime);
		intent.setClipData(ClipData.newRawUri("", uri));
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		pager.pauseAll();
		App.suppressLeave();
		try {
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			Toast.makeText(this, "No app can open this kind of file", Toast.LENGTH_LONG).show();
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (pager != null) {
			pager.pauseAll();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (pager != null) {
			pager.clear();
		}
		if (pool != null) {
			pool.shutdownNow();
		}
	}
}
