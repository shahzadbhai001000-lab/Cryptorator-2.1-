package app.safegallery;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Removes everything from a picture or a video except the picture or video itself: camera and phone model, date and
 * time, GPS position, lens and flash data, software names, thumbnails, comments, and data hidden after the end of the
 * file. Nothing is re-encoded, so the quality stays the same. The only thing kept besides the media is the rotation
 * of a photo (without it the photo would be turned the wrong way) and the colour profile.
 */
final class MetadataStripper {

	private MetadataStripper() {
	}

	static boolean isJpeg(String mime) {
		return "image/jpeg".equals(mime) || "image/jpg".equals(mime);
	}

	static boolean isStillImage(String mime) {
		return isJpeg(mime) || "image/png".equals(mime) || "image/webp".equals(mime) || "image/gif".equals(mime);
	}

	static boolean isMp4Family(String mime) {
		return "video/mp4".equals(mime) || "video/quicktime".equals(mime) || "video/3gpp".equals(mime) || "video/x-m4v".equals(mime) || "video/3gpp2".equals(mime);
	}

	static byte[] stripImage(String mime, byte[] data) throws IOException {
		if (isJpeg(mime)) {
			return stripJpeg(data);
		}
		if ("image/png".equals(mime)) {
			return stripPng(data);
		}
		if ("image/webp".equals(mime)) {
			return stripWebp(data);
		}
		if ("image/gif".equals(mime)) {
			return stripGif(data);
		}
		throw new IOException("Unsupported type " + mime);
	}

	private static int u8(byte[] d, int p) {
		return d[p] & 0xFF;
	}

	private static boolean startsWith(byte[] d, int p, String text) {
		byte[] t = text.getBytes(StandardCharsets.ISO_8859_1);
		if (p + t.length > d.length) {
			return false;
		}
		for (int i = 0; i < t.length; i++) {
			if (d[p + i] != t[i]) {
				return false;
			}
		}
		return true;
	}

	// ----- JPEG -----

	static byte[] stripJpeg(byte[] d) throws IOException {
		if (d.length < 4 || u8(d, 0) != 0xFF || u8(d, 1) != 0xD8) {
			throw new IOException("Not a JPEG");
		}
		int orientation = exifOrientation(d);
		ByteArrayOutputStream out = new ByteArrayOutputStream(d.length);
		out.write(0xFF);
		out.write(0xD8);
		if (orientation > 1 && orientation <= 8) {
			writeOrientationOnly(out, orientation);
		}
		int p = 2;
		while (p + 1 < d.length) {
			if (u8(d, p) != 0xFF) {
				throw new IOException("Broken JPEG");
			}
			int marker = u8(d, p + 1);
			if (marker == 0xFF) {
				p++;
				continue;
			}
			if (marker == 0xD9) {
				out.write(0xFF);
				out.write(0xD9);
				return out.toByteArray();
			}
			if (marker == 0x01 || (marker >= 0xD0 && marker <= 0xD8)) {
				p += 2;
				continue;
			}
			if (p + 3 >= d.length) {
				throw new IOException("Broken JPEG");
			}
			int length = (u8(d, p + 2) << 8) | u8(d, p + 3);
			int end = p + 2 + length;
			if (length < 2 || end > d.length) {
				throw new IOException("Broken JPEG");
			}
			if (marker == 0xDA) {
				int q = end;
				while (q + 1 < d.length) {
					if (u8(d, q) == 0xFF) {
						int m = u8(d, q + 1);
						if (m == 0x00 || (m >= 0xD0 && m <= 0xD7)) {
							q += 2;
							continue;
						}
						if (m == 0xFF) {
							q++;
							continue;
						}
						break;
					}
					q++;
				}
				out.write(d, p, q - p);
				p = q;
				continue;
			}
			boolean keep;
			if (marker == 0xFE) {
				keep = false;
			} else if (marker >= 0xE0 && marker <= 0xEF) {
				keep = (marker == 0xE0 && startsWith(d, p + 4, "JFIF\0") && length >= 16 && u8(d, p + 4 + 12) == 0 && u8(d, p + 4 + 13) == 0)
						|| (marker == 0xE2 && startsWith(d, p + 4, "ICC_PROFILE\0"));
			} else {
				keep = true;
			}
			if (keep) {
				out.write(d, p, end - p);
			}
			p = end;
		}
		throw new IOException("JPEG has no end marker");
	}

	/** The rotation of a photo (1 means none) from its EXIF data. */
	static int exifOrientation(byte[] d) {
		int p = 2;
		while (p + 4 < d.length && u8(d, p) == 0xFF) {
			int marker = u8(d, p + 1);
			if (marker == 0xDA || marker == 0xD9) {
				return 1;
			}
			if (marker == 0xFF) {
				p++;
				continue;
			}
			if (marker == 0x01 || (marker >= 0xD0 && marker <= 0xD8)) {
				p += 2;
				continue;
			}
			int length = (u8(d, p + 2) << 8) | u8(d, p + 3);
			int end = p + 2 + length;
			if (length < 2 || end > d.length) {
				return 1;
			}
			if (marker == 0xE1 && startsWith(d, p + 4, "Exif\0\0")) {
				return tiffOrientation(d, p + 10, end);
			}
			p = end;
		}
		return 1;
	}

	private static int tiffOrientation(byte[] d, int tiff, int end) {
		if (tiff + 8 > end) {
			return 1;
		}
		boolean big = d[tiff] == 'M';
		if (!big && d[tiff] != 'I') {
			return 1;
		}
		long ifd = u32(d, tiff + 4, big);
		long p = tiff + ifd;
		if (p + 2 > end) {
			return 1;
		}
		int count = u16(d, (int) p, big);
		p += 2;
		for (int i = 0; i < count && p + 12 <= end; i++, p += 12) {
			if (u16(d, (int) p, big) == 0x0112) {
				int value = u16(d, (int) p + 8, big);
				return value >= 1 && value <= 8 ? value : 1;
			}
		}
		return 1;
	}

	private static int u16(byte[] d, int p, boolean big) {
		return big ? (u8(d, p) << 8) | u8(d, p + 1) : (u8(d, p + 1) << 8) | u8(d, p);
	}

	private static long u32(byte[] d, int p, boolean big) {
		return big
				? ((long) u8(d, p) << 24) | (u8(d, p + 1) << 16) | (u8(d, p + 2) << 8) | u8(d, p + 3)
				: ((long) u8(d, p + 3) << 24) | (u8(d, p + 2) << 16) | (u8(d, p + 1) << 8) | u8(d, p);
	}

	private static void writeOrientationOnly(ByteArrayOutputStream out, int orientation) {
		byte[] exif = {
				(byte) 0xFF, (byte) 0xE1, 0x00, 0x22,
				'E', 'x', 'i', 'f', 0, 0,
				'M', 'M', 0x00, 0x2A, 0x00, 0x00, 0x00, 0x08,
				0x00, 0x01,
				0x01, 0x12, 0x00, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, (byte) orientation, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00
		};
		out.write(exif, 0, exif.length);
	}

	// ----- PNG -----

	private static final Set<String> PNG_KEEP = new HashSet<>(Arrays.asList(
			"IHDR", "PLTE", "IDAT", "IEND", "tRNS", "gAMA", "cHRM", "sRGB", "iCCP", "cICP", "acTL", "fcTL", "fdAT"));

	static byte[] stripPng(byte[] d) throws IOException {
		byte[] signature = {(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
		if (d.length < 8 || !Arrays.equals(Arrays.copyOf(d, 8), signature)) {
			throw new IOException("Not a PNG");
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream(d.length);
		out.write(d, 0, 8);
		int p = 8;
		while (p + 12 <= d.length) {
			long length = u32(d, p, true);
			String type = new String(d, p + 4, 4, StandardCharsets.ISO_8859_1);
			long total = 12 + length;
			if (length < 0 || p + total > d.length) {
				throw new IOException("Broken PNG");
			}
			if (PNG_KEEP.contains(type)) {
				out.write(d, p, (int) total);
			}
			p += (int) total;
			if (type.equals("IEND")) {
				return out.toByteArray();
			}
		}
		throw new IOException("PNG has no end");
	}

	// ----- WebP -----

	static byte[] stripWebp(byte[] d) throws IOException {
		if (d.length < 12 || !startsWith(d, 0, "RIFF") || !startsWith(d, 8, "WEBP")) {
			throw new IOException("Not a WebP");
		}
		long riffSize = u32(d, 4, false);
		int limit = (int) Math.min(d.length, riffSize + 8);
		ByteArrayOutputStream out = new ByteArrayOutputStream(d.length);
		out.write(d, 0, 12);
		int p = 12;
		while (p + 8 <= limit) {
			String type = new String(d, p, 4, StandardCharsets.ISO_8859_1);
			long length = u32(d, p + 4, false);
			long padded = length + (length & 1);
			if (p + 8 + padded > d.length) {
				throw new IOException("Broken WebP");
			}
			if (!type.equals("EXIF") && !type.equals("XMP ")) {
				int start = out.size();
				out.write(d, p, (int) (8 + padded));
				if (type.equals("VP8X")) {
					byte[] so = out.toByteArray();
					so[start + 8] = (byte) (so[start + 8] & ~0x0C);
					out.reset();
					out.write(so, 0, so.length);
				}
			}
			p += (int) (8 + padded);
		}
		byte[] result = out.toByteArray();
		long size = result.length - 8;
		result[4] = (byte) size;
		result[5] = (byte) (size >> 8);
		result[6] = (byte) (size >> 16);
		result[7] = (byte) (size >> 24);
		return result;
	}

	// ----- GIF -----

	static byte[] stripGif(byte[] d) throws IOException {
		if (d.length < 13 || !(startsWith(d, 0, "GIF87a") || startsWith(d, 0, "GIF89a"))) {
			throw new IOException("Not a GIF");
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream(d.length);
		int flags = u8(d, 10);
		int p = 13;
		if ((flags & 0x80) != 0) {
			p += 3 * (1 << ((flags & 7) + 1));
		}
		if (p > d.length) {
			throw new IOException("Broken GIF");
		}
		out.write(d, 0, p);
		while (p < d.length) {
			int block = u8(d, p);
			if (block == 0x3B) {
				out.write(0x3B);
				return out.toByteArray();
			}
			if (block == 0x2C) {
				if (p + 10 > d.length) {
					throw new IOException("Broken GIF");
				}
				int start = p;
				int packed = u8(d, p + 9);
				p += 10;
				if ((packed & 0x80) != 0) {
					p += 3 * (1 << ((packed & 7) + 1));
				}
				p += 1;
				p = skipSubBlocks(d, p);
				out.write(d, start, p - start);
			} else if (block == 0x21) {
				if (p + 2 > d.length) {
					throw new IOException("Broken GIF");
				}
				int label = u8(d, p + 1);
				int start = p;
				boolean keep = label == 0xF9;
				if (label == 0xFF && p + 14 <= d.length) {
					keep = startsWith(d, p + 3, "NETSCAPE2.0") || startsWith(d, p + 3, "ANIMEXTS1.0");
				}
				p = skipSubBlocks(d, p + 2);
				if (keep) {
					out.write(d, start, p - start);
				}
			} else {
				throw new IOException("Broken GIF");
			}
		}
		throw new IOException("GIF has no end");
	}

	private static int skipSubBlocks(byte[] d, int p) throws IOException {
		while (true) {
			if (p >= d.length) {
				throw new IOException("Broken GIF");
			}
			int size = u8(d, p);
			p += 1 + size;
			if (size == 0) {
				return p;
			}
		}
	}

	// ----- MP4 / MOV / 3GP -----

	private static final Set<String> TOP_KEEP = new HashSet<>(Arrays.asList("ftyp", "styp", "moov", "mdat", "moof", "mfra", "sidx", "ssix"));
	private static final Set<String> MOOV_KEEP = new HashSet<>(Arrays.asList("mvhd", "trak", "mvex", "iods", "pssh"));
	private static final Set<String> DROP_TRACK_TYPES = new HashSet<>(Arrays.asList("meta", "mett", "mebx", "camm", "gpmd", "tmcd"));
	private static final Set<String> VIDEO_ENTRIES = new HashSet<>(Arrays.asList("avc1", "avc3", "hvc1", "hev1", "mp4v", "vp09", "av01", "s263"));

	/** True if the first bytes of a file look like those of an MP4 style file. */
	static boolean looksLikeMp4(byte[] head, int length) {
		return length >= 12 && startsWith(head, 4, "ftyp");
	}

	/**
	 * Copies an MP4 style file and wipes its metadata. The atoms that hold it are not removed but overwritten with
	 * zeros and renamed "free", so the size of the file and every position in it stay the same and the video plays
	 * exactly as before.
	 */
	static void stripMp4(InputStream rawIn, OutputStream out) throws IOException {
		DataInputStream in = new DataInputStream(new BufferedInputStream(rawIn, 1 << 16));
		byte[] zeros = new byte[1 << 16];
		byte[] buf = new byte[1 << 16];
		while (true) {
			byte[] head = new byte[8];
			int n = readUpTo(in, head);
			if (n == 0) {
				return;
			}
			if (n < 8) {
				throw new IOException("Broken video");
			}
			long size = u32(head, 0, true);
			String type = new String(head, 4, 4, StandardCharsets.ISO_8859_1);
			byte[] extended = null;
			long headerLength = 8;
			if (size == 1) {
				extended = new byte[8];
				in.readFully(extended);
				size = ((u32(extended, 0, true)) << 32) | u32(extended, 4, true);
				headerLength = 16;
			} else if (size == 0) {
				out.write(head);
				int r;
				while ((r = in.read(buf)) >= 0) {
					out.write(buf, 0, r);
				}
				return;
			}
			long payload = size - headerLength;
			if (payload < 0) {
				throw new IOException("Broken video");
			}
			if (type.equals("moov")) {
				if (payload > 512L * 1024 * 1024) {
					throw new IOException("Video header is too big");
				}
				byte[] moov = new byte[(int) payload];
				in.readFully(moov);
				cleanContainer(moov, 0, moov.length, "moov");
				out.write(head);
				if (extended != null) {
					out.write(extended);
				}
				out.write(moov);
			} else if (type.equals("mdat")) {
				out.write(head);
				if (extended != null) {
					out.write(extended);
				}
				int first = (int) Math.min(payload, 256 * 1024);
				byte[] start = new byte[first];
				in.readFully(start);
				blankEncoderText(start);
				out.write(start);
				copy(in, out, payload - first, buf);
			} else if (TOP_KEEP.contains(type)) {
				out.write(head);
				if (extended != null) {
					out.write(extended);
				}
				copy(in, out, payload, buf);
			} else {
				byte[] freeHead = head.clone();
				System.arraycopy("free".getBytes(StandardCharsets.ISO_8859_1), 0, freeHead, 4, 4);
				out.write(freeHead);
				if (extended != null) {
					out.write(extended);
				}
				skip(in, payload, buf);
				long left = payload;
				while (left > 0) {
					int chunk = (int) Math.min(left, zeros.length);
					out.write(zeros, 0, chunk);
					left -= chunk;
				}
			}
		}
	}

	/** Encoders such as x264 write their name and settings into the first frame. They are replaced by spaces. */
	private static void blankEncoderText(byte[] b) {
		byte[] needle = "x264 - core".getBytes(StandardCharsets.ISO_8859_1);
		outer:
		for (int i = 0; i + needle.length < b.length; i++) {
			for (int j = 0; j < needle.length; j++) {
				if (b[i + j] != needle[j]) {
					continue outer;
				}
			}
			int k = i;
			while (k < b.length && b[k] != 0 && (b[k] & 0xFF) >= 0x20 && (b[k] & 0xFF) < 0x7F) {
				b[k++] = 0x20;
			}
			return;
		}
	}

	private static int readUpTo(DataInputStream in, byte[] b) throws IOException {
		int total = 0;
		while (total < b.length) {
			int n = in.read(b, total, b.length - total);
			if (n < 0) {
				break;
			}
			total += n;
		}
		return total;
	}

	private static void copy(InputStream in, OutputStream out, long count, byte[] buf) throws IOException {
		while (count > 0) {
			int n = in.read(buf, 0, (int) Math.min(buf.length, count));
			if (n < 0) {
				throw new IOException("Video is cut off");
			}
			out.write(buf, 0, n);
			count -= n;
		}
	}

	private static void skip(InputStream in, long count, byte[] buf) throws IOException {
		while (count > 0) {
			int n = in.read(buf, 0, (int) Math.min(buf.length, count));
			if (n < 0) {
				throw new IOException("Video is cut off");
			}
			count -= n;
		}
	}

	private static void wipe(byte[] b, int from, int to) {
		Arrays.fill(b, from, to, (byte) 0);
	}

	private static void makeFree(byte[] b, int atom, int end) {
		byte[] free = "free".getBytes(StandardCharsets.ISO_8859_1);
		System.arraycopy(free, 0, b, atom + 4, 4);
		wipe(b, atom + 8, end);
	}

	private static void cleanContainer(byte[] b, int start, int end, String parent) {
		int p = start;
		while (p + 8 <= end) {
			long size = u32(b, p, true);
			String type = new String(b, p + 4, 4, StandardCharsets.ISO_8859_1);
			int header = 8;
			if (size == 1) {
				if (p + 16 > end) {
					return;
				}
				size = (u32(b, p + 8, true) << 32) | u32(b, p + 12, true);
				header = 16;
			} else if (size == 0) {
				size = end - p;
			}
			if (size < header || p + size > end) {
				return;
			}
			int atomEnd = (int) (p + size);
			int payload = p + header;
			if (parent.equals("moov")) {
				if (!MOOV_KEEP.contains(type)) {
					makeFree(b, p, atomEnd);
				} else if (type.equals("mvhd")) {
					zeroTimes(b, payload, atomEnd);
				} else if (type.equals("trak")) {
					if (DROP_TRACK_TYPES.contains(trackHandler(b, payload, atomEnd))) {
						makeFree(b, p, atomEnd);
					} else {
						cleanContainer(b, payload, atomEnd, "trak");
					}
				}
			} else if (type.equals("udta") || type.equals("meta") || type.equals("uuid") || type.equals("free") || type.equals("skip") || type.equals("tref")) {
				makeFree(b, p, atomEnd);
			} else if (type.equals("tkhd") || type.equals("mdhd")) {
				zeroTimes(b, payload, atomEnd);
			} else if (type.equals("hdlr")) {
				if (payload + 12 < atomEnd) {
					wipe(b, payload + 12, atomEnd);
				}
			} else if (type.equals("stsd")) {
				cleanSampleEntries(b, payload + 8, atomEnd);
			} else if (type.equals("trak") || type.equals("mdia") || type.equals("minf") || type.equals("stbl")) {
				cleanContainer(b, payload, atomEnd, type);
			}
			p = atomEnd;
		}
	}

	/** The creation and modification times of a header atom. */
	private static void zeroTimes(byte[] b, int payload, int end) {
		if (payload + 4 > end) {
			return;
		}
		int version = u8(b, payload);
		int length = version == 1 ? 16 : 8;
		if (payload + 4 + length <= end) {
			wipe(b, payload + 4, payload + 4 + length);
		}
	}

	private static String trackHandler(byte[] b, int start, int end) {
		int p = start;
		while (p + 8 <= end) {
			long size = u32(b, p, true);
			String type = new String(b, p + 4, 4, StandardCharsets.ISO_8859_1);
			if (size < 8 || p + size > end) {
				return "";
			}
			if (type.equals("mdia")) {
				int q = p + 8;
				int mdiaEnd = (int) (p + size);
				while (q + 8 <= mdiaEnd) {
					long inner = u32(b, q, true);
					String innerType = new String(b, q + 4, 4, StandardCharsets.ISO_8859_1);
					if (inner < 8 || q + inner > mdiaEnd) {
						return "";
					}
					if (innerType.equals("hdlr") && q + 8 + 12 <= mdiaEnd) {
						return new String(b, q + 8 + 8, 4, StandardCharsets.ISO_8859_1);
					}
					q += (int) inner;
				}
			}
			p += (int) size;
		}
		return "";
	}

	/** Wipes the name of the encoder that video sample entries carry. */
	private static void cleanSampleEntries(byte[] b, int start, int end) {
		int p = start;
		while (p + 8 <= end) {
			long size = u32(b, p, true);
			String type = new String(b, p + 4, 4, StandardCharsets.ISO_8859_1);
			if (size < 8 || p + size > end) {
				return;
			}
			if (VIDEO_ENTRIES.contains(type) && size >= 86) {
				wipe(b, p + 50, p + 82);
			}
			p += (int) size;
		}
	}
}
