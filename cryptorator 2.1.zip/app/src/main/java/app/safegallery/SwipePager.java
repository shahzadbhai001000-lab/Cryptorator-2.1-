package app.safegallery;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/** Shows one page and lets the person swipe sideways to the one before or after it, like a gallery. */
final class SwipePager extends FrameLayout {

	interface Adapter {
		int count();

		Page create(int position);
	}

	interface Listener {
		void onPageSelected(int position);
	}

	abstract static class Page extends FrameLayout {
		Page(Context context) {
			super(context);
		}

		/** The page is now the one in front: start loading or playing. */
		void activate() {
		}

		/** The page is no longer in front. */
		void deactivate() {
		}

		/** The activity goes to the background. */
		void pause() {
		}

		/** The page is dropped for good. */
		void release() {
		}

		/** Called when the bars on top of the page are shown or hidden. */
		void setChromeVisible(boolean visible) {
		}

		/** @param direction 1 if the finger moves to the right, -1 to the left */
		boolean canPan(int direction) {
			return false;
		}
	}

	private final int slop;
	private final int minFling;
	private Adapter adapter;
	private Listener listener;
	private int position;
	private final Page[] slots = new Page[3];
	private float offset;
	private float downX;
	private float downY;
	private boolean dragging;
	private VelocityTracker velocity;
	private ValueAnimator animator;
	private boolean chrome = true;

	SwipePager(Context context) {
		super(context);
		ViewConfiguration vc = ViewConfiguration.get(context);
		slop = vc.getScaledTouchSlop();
		minFling = Math.max(400, vc.getScaledMinimumFlingVelocity() * 4);
	}

	void setListener(Listener listener) {
		this.listener = listener;
	}

	int position() {
		return position;
	}

	Page current() {
		return slots[1];
	}

	void setAdapter(Adapter adapter, int start) {
		clear();
		this.adapter = adapter;
		position = Math.max(0, Math.min(start, adapter.count() - 1));
		offset = 0;
		if (adapter.count() == 0) {
			return;
		}
		slots[0] = make(position - 1);
		slots[1] = make(position);
		slots[2] = make(position + 1);
		place();
		slots[1].activate();
		if (listener != null) {
			listener.onPageSelected(position);
		}
	}

	/** The content changed (a file was deleted): shows the page at [start] again. */
	void reload(int start) {
		Adapter a = adapter;
		Listener l = listener;
		setAdapter(a, start);
		if (a.count() == 0 && l != null) {
			l.onPageSelected(-1);
		}
	}

	void setChromeVisible(boolean visible) {
		chrome = visible;
		if (slots[1] != null) {
			slots[1].setChromeVisible(visible);
		}
	}

	void pauseAll() {
		for (Page p : slots) {
			if (p != null) {
				p.pause();
			}
		}
	}

	void clear() {
		if (animator != null) {
			animator.cancel();
		}
		for (int i = 0; i < slots.length; i++) {
			if (slots[i] != null) {
				slots[i].deactivate();
				slots[i].release();
				removeView(slots[i]);
				slots[i] = null;
			}
		}
	}

	private Page make(int index) {
		if (adapter == null || index < 0 || index >= adapter.count()) {
			return null;
		}
		Page page = adapter.create(index);
		addView(page, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		page.setChromeVisible(chrome);
		return page;
	}

	private void place() {
		int w = getWidth();
		for (int i = 0; i < 3; i++) {
			if (slots[i] != null) {
				slots[i].setTranslationX((i - 1) * w + offset);
			}
		}
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		place();
	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		switch (ev.getActionMasked()) {
			case MotionEvent.ACTION_DOWN:
				if (animator != null && animator.isRunning()) {
					animator.end();
				}
				downX = ev.getX();
				downY = ev.getY();
				dragging = false;
				break;
			case MotionEvent.ACTION_MOVE:
				if (ev.getPointerCount() > 1 || slots[1] == null) {
					return false;
				}
				float dx = ev.getX() - downX;
				float dy = ev.getY() - downY;
				if (!dragging && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
					if (slots[1].canPan(dx > 0 ? 1 : -1)) {
						return false;
					}
					dragging = true;
					downX = ev.getX();
					startTracking(ev);
					return true;
				}
				break;
			default:
				break;
		}
		return dragging;
	}

	private void startTracking(MotionEvent ev) {
		if (velocity != null) {
			velocity.recycle();
		}
		velocity = VelocityTracker.obtain();
		velocity.addMovement(ev);
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		if (!dragging) {
			return ev.getActionMasked() == MotionEvent.ACTION_DOWN && slots[1] != null;
		}
		if (velocity == null) {
			startTracking(ev);
		}
		velocity.addMovement(ev);
		switch (ev.getActionMasked()) {
			case MotionEvent.ACTION_MOVE: {
				float raw = ev.getX() - downX;
				boolean noPrev = slots[0] == null && raw > 0;
				boolean noNext = slots[2] == null && raw < 0;
				offset = noPrev || noNext ? raw / 4f : raw;
				place();
				return true;
			}
			case MotionEvent.ACTION_UP:
			case MotionEvent.ACTION_CANCEL: {
				velocity.computeCurrentVelocity(1000);
				float vx = velocity.getXVelocity();
				velocity.recycle();
				velocity = null;
				dragging = false;
				int w = Math.max(1, getWidth());
				int direction = 0; // -1 shows the next page, 1 the previous
				if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
					if ((offset > w / 4f || vx > minFling) && slots[0] != null) {
						direction = 1;
					} else if ((offset < -w / 4f || vx < -minFling) && slots[2] != null) {
						direction = -1;
					}
				}
				settle(direction);
				return true;
			}
			default:
				return true;
		}
	}

	private void settle(final int direction) {
		final float from = offset;
		final float to = direction * getWidth();
		if (animator != null) {
			animator.cancel();
		}
		animator = ValueAnimator.ofFloat(from, to);
		animator.setDuration(direction == 0 ? 160 : 220);
		animator.setInterpolator(new DecelerateInterpolator());
		animator.addUpdateListener(a -> {
			offset = (Float) a.getAnimatedValue();
			place();
		});
		animator.addListener(new AnimatorListenerAdapter() {
			private boolean cancelled;

			@Override
			public void onAnimationCancel(Animator a) {
				cancelled = true;
			}

			@Override
			public void onAnimationEnd(Animator a) {
				if (cancelled) {
					return;
				}
				offset = to;
				place();
				finishMove(direction);
			}
		});
		animator.start();
	}

	private void finishMove(int direction) {
		offset = 0;
		if (direction == 0) {
			place();
			return;
		}
		slots[1].deactivate();
		if (direction < 0) {
			drop(slots[0]);
			slots[0] = slots[1];
			slots[1] = slots[2];
			position++;
			slots[2] = make(position + 1);
		} else {
			drop(slots[2]);
			slots[2] = slots[1];
			slots[1] = slots[0];
			position--;
			slots[0] = make(position - 1);
		}
		place();
		slots[1].activate();
		slots[1].setChromeVisible(chrome);
		if (listener != null) {
			listener.onPageSelected(position);
		}
	}

	private void drop(Page page) {
		if (page != null) {
			page.release();
			removeView(page);
		}
	}

	@Override
	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		if (animator != null) {
			animator.cancel();
		}
	}

	/** Used by pages to forward a plain tap. */
	static void tap(View v, Runnable r) {
		v.setOnClickListener(x -> r.run());
	}
}
