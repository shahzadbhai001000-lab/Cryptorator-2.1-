package app.safegallery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {

	private static final int REQ_PICK = 1;
	private static final int REQ_FOLDER = 2;

	private static final long[] DELAYS = {0, 15_000, 30_000, 60_000, 5 * 60_000, 15 * 60_000, Settings.LOCK_NEVER};
	private static final String[] DELAY_NAMES = {"Right away when I leave the app", "After 15 seconds", "After 30 seconds", "After 1 minute", "After 5 minutes", "After 15 minutes", "Never (until I lock it or close the app)"};
	private static final String[] LEVELS = {"Low (hard shake)", "Medium", "High (light shake)"};

	private LinearLayout box;
	private final List<Uri> picked = new ArrayList<>();
	private TextView status;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("Settings");
		if (Settings.blockScreenshots(this)) {
			getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
		}
		ScrollView scroll = new ScrollView(this);
		scroll.setBackgroundColor(Color.BLACK);
		box = new LinearLayout(this);
		box.setOrientation(LinearLayout.VERTICAL);
		scroll.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		setContentView(scroll);
		build();
	}

	private int dp(int v) {
		return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
	}

	private void header(String text) {
		TextView t = new TextView(this);
		t.setText(text);
		t.setTextColor(0xFF4CAF50);
		t.setTextSize(13);
		t.setPadding(dp(16), dp(20), dp(16), dp(4));
		box.addView(t);
	}

	private TextView[] row(String title, String subtitle, View.OnClickListener click) {
		LinearLayout r = new LinearLayout(this);
		r.setOrientation(LinearLayout.VERTICAL);
		r.setPadding(dp(16), dp(10), dp(16), dp(10));
		TextView t = new TextView(this);
		t.setText(title);
		t.setTextColor(Color.WHITE);
		t.setTextSize(16);
		TextView s = new TextView(this);
		s.setText(subtitle);
		s.setTextColor(0xFF9E9E9E);
		s.setTextSize(13);
		r.addView(t);
		r.addView(s);
		if (click != null) {
			r.setOnClickListener(click);
		}
		box.addView(r);
		return new TextView[]{t, s};
	}

	private void toggle(String title, String subtitle, boolean value, final java.util.function.Consumer<Boolean> set) {
		LinearLayout r = new LinearLayout(this);
		r.setOrientation(LinearLayout.HORIZONTAL);
		r.setGravity(android.view.Gravity.CENTER_VERTICAL);
		r.setPadding(dp(16), dp(10), dp(16), dp(10));
		LinearLayout texts = new LinearLayout(this);
		texts.setOrientation(LinearLayout.VERTICAL);
		TextView t = new TextView(this);
		t.setText(title);
		t.setTextColor(Color.WHITE);
		t.setTextSize(16);
		TextView s = new TextView(this);
		s.setText(subtitle);
		s.setTextColor(0xFF9E9E9E);
		s.setTextSize(13);
		texts.addView(t);
		texts.addView(s);
		r.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		final Switch sw = new Switch(this);
		sw.setChecked(value);
		sw.setOnCheckedChangeListener((CompoundButton b, boolean on) -> {
			set.accept(on);
			App.touch();
		});
		r.addView(sw);
		r.setOnClickListener(v -> sw.toggle());
		box.addView(r);
	}

	private void build() {
		box.removeAllViews();

		header("LOCKING");
		long delay = Settings.lockDelay(this);
		int di = 0;
		for (int i = 0; i < DELAYS.length; i++) {
			if (DELAYS[i] == delay) {
				di = i;
			}
		}
		row("Keep the vault unlocked", DELAY_NAMES[di], v -> new AlertDialog.Builder(this).setTitle("Keep the vault unlocked").setItems(DELAY_NAMES, (d, which) -> {
			Settings.setLockDelay(this, DELAYS[which]);
			build();
		}).show());
		toggle("Lock when the screen turns off", "The vault locks the moment the screen goes dark", Settings.lockOnScreenOff(this), v -> Settings.setLockOnScreenOff(this, v));
		toggle("Lock when the phone is shaken", "Works while the app is open on the screen", Settings.lockOnShake(this), v -> Settings.setLockOnShake(this, v));
		row("Shake sensitivity", LEVELS[Settings.shakeSensitivity(this)], v -> new AlertDialog.Builder(this).setTitle("Shake sensitivity").setItems(LEVELS, (d, which) -> {
			Settings.setShakeSensitivity(this, which);
			build();
		}).show());
		toggle("Block screenshots", "Hides the vault in the recent apps list and stops screenshots", Settings.blockScreenshots(this), v -> Settings.setBlockScreenshots(this, v));

		header("SEND TO VAULT (SHARE MENU)");
		row("When I share a file to the vault", Settings.shareMove(this) ? "Move it: the original is deleted" : "Copy it: the original stays", v -> new AlertDialog.Builder(this).setTitle("When I share a file to the vault").setItems(new String[]{"Copy (the original stays)", "Move (the original is deleted)"}, (d, which) -> {
			Settings.setShareMove(this, which == 1);
			build();
		}).show());

		header("VIDEOS");
		row("Play videos with", Settings.externalVideoPlayer(this) ? "Another app (Android asks: Just once / Always)" : "The built-in player (swipe between files)", v -> new AlertDialog.Builder(this).setTitle("Play videos with").setItems(new String[]{"The built-in player", "Another app (Just once / Always)"}, (d, which) -> {
			Settings.setExternalVideoPlayer(this, which == 1);
			build();
		}).show());

		header("CLEAR MEDIA");
		toggle("Auto-clear media while encrypting", "Photos and videos lose all metadata when they go into the vault, so they stay clean when you take them out", Settings.autoClean(this), v -> Settings.setAutoClean(this, v));
		row("Clear media now", "Pick photos or videos from your phone and save clean copies", v -> {
			Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
			intent.addCategory(Intent.CATEGORY_OPENABLE);
			intent.setType("*/*");
			intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
			intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
			App.suppressLeave();
			startActivityForResult(intent, REQ_PICK);
		});
		row("What is removed", "Date and time, GPS place, phone and camera model, lens, flash and exposure data, software names, thumbnails and comments. The picture or video itself is not changed or re-compressed. The file name stays. Videos other than MP4/MOV/3GP (such as MKV) can't be cleaned.", null);
		status = new TextView(this);
		status.setTextColor(0xFF4CAF50);
		status.setPadding(dp(16), dp(4), dp(16), dp(4));
		box.addView(status);

		header("APPEARANCE");
		toggle("Disguise as Gboard", "Changes the icon and name on the home screen. The app list in Android settings always shows \"Gboard\".", Disguise.isDisguised(this), v -> {
			Disguise.set(this, v);
			Toast.makeText(this, "The icon changes in a few seconds", Toast.LENGTH_LONG).show();
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != RESULT_OK || data == null) {
			return;
		}
		if (requestCode == REQ_PICK) {
			picked.clear();
			if (data.getClipData() != null) {
				for (int i = 0; i < data.getClipData().getItemCount(); i++) {
					picked.add(data.getClipData().getItemAt(i).getUri());
				}
			} else if (data.getData() != null) {
				picked.add(data.getData());
			}
			if (picked.isEmpty()) {
				return;
			}
			Toast.makeText(this, "Now choose the folder for the clean copies", Toast.LENGTH_LONG).show();
			Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
			intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			App.suppressLeave();
			startActivityForResult(intent, REQ_FOLDER);
		} else if (requestCode == REQ_FOLDER && data.getData() != null) {
			runClean(data.getData(), new ArrayList<>(picked));
		}
	}

	private void runClean(final Uri tree, final List<Uri> uris) {
		new Thread(() -> {
			int ok = 0;
			int skipped = 0;
			int failed = 0;
			Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
			for (int i = 0; i < uris.size(); i++) {
				final String text = "Cleaning " + (i + 1) + " of " + uris.size() + "…";
				runOnUiThread(() -> status.setText(text));
				Uri uri = uris.get(i);
				String name = Importer.displayName(this, uri);
				String mime = Importer.mimeOf(this, uri, name, null);
				try (InputStream raw = getContentResolver().openInputStream(uri); MediaCleaner.Cleaned c = MediaCleaner.open(raw, true)) {
					if (!c.changed) {
						skipped++;
						continue;
					}
					int dot = name.lastIndexOf('.');
					String outName = dot > 0 ? name.substring(0, dot) + "_clean" + name.substring(dot) : name + "_clean";
					Uri dest = DocumentsContract.createDocument(getContentResolver(), parent, mime, outName);
					if (dest == null) {
						throw new java.io.IOException("no file");
					}
					boolean good = false;
					try (OutputStream out = getContentResolver().openOutputStream(dest)) {
						byte[] buf = new byte[1 << 16];
						int n;
						while ((n = c.stream.read(buf)) >= 0) {
							out.write(buf, 0, n);
						}
						c.check();
						good = true;
					} finally {
						if (!good) {
							try {
								DocumentsContract.deleteDocument(getContentResolver(), dest);
							} catch (Exception ignored) {
								// nothing to remove
							}
						}
					}
					ok++;
				} catch (Exception e) {
					failed++;
				}
			}
			final String result = "Cleaned " + ok + (skipped > 0 ? ", " + skipped + " can't be cleaned" : "") + (failed > 0 ? ", failed " + failed : "");
			runOnUiThread(() -> {
				status.setText(result);
				Toast.makeText(this, result, Toast.LENGTH_LONG).show();
			});
		}).start();
	}
}
