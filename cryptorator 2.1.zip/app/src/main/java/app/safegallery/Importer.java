package app.safegallery;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/** Reads a file of the phone for the vault: its name, its kind, a small picture of it, and its (cleaned) content. */
final class Importer {

	private Importer() {
	}

	static final class Prepared implements java.io.Closeable {
		final String name;
		final String mime;
		final byte[] thumbnail;
		final MediaCleaner.Cleaned data;

		Prepared(String name, String mime, byte[] thumbnail, MediaCleaner.Cleaned data) {
			this.name = name;
			this.mime = mime;
			this.thumbnail = thumbnail;
			this.data = data;
		}

		@Override
		public void close() throws IOException {
			data.close();
		}
	}

	static String displayName(Context context, Uri uri) {
		try (Cursor c = context.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
			if (c != null && c.moveToFirst() && c.getString(0) != null) {
				return c.getString(0);
			}
		} catch (RuntimeException ignored) {
			// no name known
		}
		String last = uri.getLastPathSegment();
		return last != null && !last.isEmpty() ? last : "file";
	}

	static String mimeOf(Context context, Uri uri, String name, String hint) {
		String mime = context.getContentResolver().getType(uri);
		if (mime == null || mime.equals("application/octet-stream") || mime.equals("*/*")) {
			mime = hint;
		}
		if (mime == null || mime.equals("application/octet-stream") || mime.equals("*/*") || mime.endsWith("/*")) {
			int dot = name.lastIndexOf('.');
			String guess = dot < 0 ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.ROOT));
			mime = guess != null ? guess : "application/octet-stream";
		}
		return mime;
	}

	static Prepared prepare(Context context, Uri uri, String hint, boolean clean) throws IOException {
		String name = displayName(context, uri);
		String mime = mimeOf(context, uri, name, hint);
		byte[] thumbnail = Thumbs.make(context, uri, mime);
		InputStream in = context.getContentResolver().openInputStream(uri);
		if (in == null) {
			throw new IOException("Cannot read " + name);
		}
		try {
			return new Prepared(name, mime, thumbnail, MediaCleaner.open(in, clean));
		} catch (IOException | RuntimeException e) {
			in.close();
			throw e;
		}
	}

	/** Encrypts a file into the open vault. The result says if it was cleaned. */
	static boolean addToVault(Context context, Vault vault, Uri uri, String folder, boolean clean) throws IOException {
		try (Prepared p = prepare(context, uri, null, clean)) {
			Index.Entry entry = vault.addFile(p.data.stream, p.name, p.mime, folder, p.thumbnail);
			try {
				p.data.check();
			} catch (IOException e) {
				java.util.List<Index.Entry> one = new java.util.ArrayList<>();
				one.add(entry);
				vault.delete(one);
				throw e;
			}
			return p.data.changed;
		}
	}
}
