package app.safegallery;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PushbackInputStream;
import java.util.concurrent.atomic.AtomicReference;

/** Gives a stream of a picture or video without its metadata. The kind of file is found from its first bytes. */
final class MediaCleaner {

	private static final int MAX_IMAGE = 256 * 1024 * 1024;

	private MediaCleaner() {
	}

	static final class Cleaned implements java.io.Closeable {
		final InputStream stream;
		/** True if this is a cleaned copy, false if the file is of a kind that cannot be cleaned and is passed on as it is. */
		final boolean changed;
		private final AtomicReference<Throwable> error;
		private final String note;

		Cleaned(InputStream stream, boolean changed, AtomicReference<Throwable> error, String note) {
			this.stream = stream;
			this.changed = changed;
			this.error = error;
			this.note = note;
		}

		/** Call after the stream was read to its end: a video is cleaned while it is read, and that can fail late. */
		void check() throws IOException {
			Throwable t = error == null ? null : error.get();
			if (t != null) {
				throw new IOException("Could not clean the file: " + t.getMessage(), t);
			}
		}

		String note() {
			return note;
		}

		@Override
		public void close() throws IOException {
			stream.close();
		}
	}

	static Cleaned open(InputStream raw, boolean clean) throws IOException {
		if (!clean) {
			return new Cleaned(raw, false, null, null);
		}
		final PushbackInputStream in = new PushbackInputStream(raw, 16);
		byte[] head = new byte[12];
		int n = 0;
		while (n < head.length) {
			int r = in.read(head, n, head.length - n);
			if (r < 0) {
				break;
			}
			n += r;
		}
		if (n > 0) {
			in.unread(head, 0, n);
		}
		String kind = kind(head, n);
		if (kind == null) {
			return new Cleaned(in, false, null, "This kind of file can't be cleaned");
		}
		if (kind.equals("mp4")) {
			final PipedInputStream pipeIn = new PipedInputStream(1 << 18);
			final PipedOutputStream pipeOut = new PipedOutputStream(pipeIn);
			final AtomicReference<Throwable> error = new AtomicReference<>();
			Thread writer = new Thread(() -> {
				try {
					MetadataStripper.stripMp4(in, pipeOut);
				} catch (Throwable t) {
					error.set(t);
				} finally {
					try {
						pipeOut.close();
					} catch (IOException ignored) {
						// reader is gone
					}
				}
			}, "sg-clean");
			writer.setDaemon(true);
			writer.start();
			return new Cleaned(pipeIn, true, error, null);
		}
		ByteArrayOutputStream all = new ByteArrayOutputStream(1 << 16);
		byte[] buf = new byte[1 << 16];
		int r;
		while ((r = in.read(buf)) >= 0) {
			all.write(buf, 0, r);
			if (all.size() > MAX_IMAGE) {
				throw new IOException("Picture is too big to clean");
			}
		}
		byte[] original = all.toByteArray();
		try {
			String mime = kind.equals("jpeg") ? "image/jpeg" : "image/" + kind;
			return new Cleaned(new ByteArrayInputStream(MetadataStripper.stripImage(mime, original)), true, null, null);
		} catch (IOException e) {
			return new Cleaned(new ByteArrayInputStream(original), false, null, "Could not clean: " + e.getMessage());
		}
	}

	private static String kind(byte[] h, int n) {
		if (n >= 3 && (h[0] & 0xFF) == 0xFF && (h[1] & 0xFF) == 0xD8 && (h[2] & 0xFF) == 0xFF) {
			return "jpeg";
		}
		if (n >= 8 && (h[0] & 0xFF) == 0x89 && h[1] == 'P' && h[2] == 'N' && h[3] == 'G') {
			return "png";
		}
		if (n >= 6 && h[0] == 'G' && h[1] == 'I' && h[2] == 'F' && h[3] == '8') {
			return "gif";
		}
		if (n >= 12 && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') {
			return "webp";
		}
		if (n >= 12 && h[4] == 'f' && h[5] == 't' && h[6] == 'y' && h[7] == 'p') {
			return "mp4";
		}
		return null;
	}
}
