package app.safegallery;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/** An unlocked vault: the master key, the index and the store. All changes go through here. */
final class Vault {

	static final class WrongPasswordException extends IOException {
		WrongPasswordException() {
			super("Wrong password");
		}
	}

	static final String CFG = "vault.cfg";
	static final String INDEX = "index.sgv";
	static final String INDEX_BAK = "index.bak";
	static final String INBOX_KEY = "inbox.key";
	static final String INBOX = "inbox";
	private static final int ITERATIONS = 400000;
	private static final byte[] CHECK = "SAFE-GALLERY-VAULT-1".getBytes(StandardCharsets.UTF_8);

	private final Store store;
	private final byte[] master;
	private final Index index;

	private Vault(Store store, byte[] master, Index index) {
		this.store = store;
		this.master = master;
		this.index = index;
	}

	// ----- creating and opening -----

	static Vault create(Store store, char[] password) throws IOException {
		if (store.exists(CFG)) {
			throw new IOException("This folder already contains a vault");
		}
		byte[] salt = Crypto.random(16);
		byte[] key = Crypto.deriveKey(password, salt, ITERATIONS);
		Properties p = new Properties();
		p.setProperty("version", "1");
		p.setProperty("salt", Base64.getEncoder().encodeToString(salt));
		p.setProperty("iterations", String.valueOf(ITERATIONS));
		p.setProperty("check", Base64.getEncoder().encodeToString(Crypto.encryptBytes(key, CHECK)));
		Vault vault = new Vault(store, key, new Index());
		vault.createInboxKeys(p);
		vault.saveIndex();
		return vault;
	}

	static Vault open(Store store, char[] password) throws IOException {
		Properties p = readConfig(store);
		byte[] salt = Base64.getDecoder().decode(p.getProperty("salt", ""));
		int iterations = Integer.parseInt(p.getProperty("iterations", String.valueOf(ITERATIONS)));
		return finishOpen(store, p, Crypto.deriveKey(password, salt, iterations));
	}

	/** Opens the vault with its key, which skips the slow step of turning the password into the key. */
	static Vault openWithKey(Store store, byte[] key) throws IOException {
		return finishOpen(store, readConfig(store), key.clone());
	}

	private static Properties readConfig(Store store) throws IOException {
		if (!store.exists(CFG)) {
			throw new FileNotFoundException("There is no vault in this folder");
		}
		Properties p = new Properties();
		try (InputStream in = store.open(CFG)) {
			p.load(in);
		}
		return p;
	}

	private static Vault finishOpen(Store store, Properties p, byte[] key) throws IOException {
		try {
			byte[] check = Crypto.decryptBytes(key, Base64.getDecoder().decode(p.getProperty("check", "")));
			if (!Arrays.equals(check, CHECK)) {
				throw new WrongPasswordException();
			}
		} catch (IOException | IllegalArgumentException e) {
			throw new WrongPasswordException();
		}
		Vault vault = new Vault(store, key, loadIndex(store, key));
		if (!p.containsKey("pub")) {
			vault.createInboxKeys(p);
		}
		return vault;
	}

	private void createInboxKeys(Properties p) throws IOException {
		Inbox.Keys keys = Inbox.generateKeys();
		try (OutputStream out = store.create(INBOX_KEY)) {
			out.write(Crypto.encryptBytes(master, keys.privateKey));
		}
		p.setProperty("pub", Base64.getEncoder().encodeToString(keys.publicKey));
		try (OutputStream out = store.create(CFG)) {
			p.store(out, null);
		}
	}

	/** The public key that files can be encrypted to without the password. It is not secret. */
	static byte[] readPublicKey(Store store) throws IOException {
		String pub = readConfig(store).getProperty("pub");
		if (pub == null) {
			throw new IOException("Open this vault once with your password first");
		}
		return Base64.getDecoder().decode(pub);
	}

	byte[] keyBytes() {
		return master.clone();
	}

	private static Index loadIndex(Store store, byte[] key) throws IOException {
		IOException first = null;
		for (String name : new String[]{INDEX, INDEX_BAK}) {
			try {
				if (store.exists(name)) {
					return Index.fromBytes(Crypto.decryptBytes(key, readAll(store.open(name))));
				}
			} catch (IOException e) {
				if (first == null) {
					first = e;
				}
			}
		}
		throw first != null ? first : new FileNotFoundException("The vault's index is missing");
	}

	static byte[] readAll(InputStream in) throws IOException {
		try (InputStream input = in) {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[65536];
			int n;
			while ((n = input.read(buf)) >= 0) {
				out.write(buf, 0, n);
			}
			return out.toByteArray();
		}
	}

	private void saveIndex() throws IOException {
		byte[] enc = Crypto.encryptBytes(master, index.toBytes());
		try (OutputStream out = store.create(INDEX)) {
			out.write(enc);
		}
		try (OutputStream out = store.create(INDEX_BAK)) {
			out.write(enc);
		}
	}

	// ----- listing -----

	synchronized List<Index.Entry> entriesIn(String folder) {
		List<Index.Entry> result = new ArrayList<>();
		for (Index.Entry e : index.entries) {
			if (e.folder.equals(folder)) {
				result.add(e);
			}
		}
		return result;
	}

	synchronized List<String> foldersIn(String parent) {
		List<String> result = new ArrayList<>();
		for (String f : index.folders) {
			if (Index.parentOf(f).equals(parent)) {
				result.add(f);
			}
		}
		return result;
	}

	synchronized List<String> allFolders() {
		return new ArrayList<>(index.folders);
	}

	synchronized Index.Entry find(String id) {
		for (Index.Entry e : index.entries) {
			if (e.id.equals(id)) {
				return e;
			}
		}
		return null;
	}

	// ----- adding -----

	synchronized Index.Entry addFile(InputStream in, String name, String mime, String folder, byte[] thumbnail) throws IOException {
		Index.Entry entry = write(in, name, mime, folder, thumbnail, System.currentTimeMillis());
		index.entries.add(entry);
		try {
			saveIndex();
		} catch (IOException | RuntimeException e) {
			index.entries.remove(entry);
			quietDelete(entry.file);
			quietDelete(entry.thumb);
			throw e;
		}
		return entry;
	}

	/** Writes the encrypted file and its thumbnail, and cleans up if that fails. The index is not changed. */
	private Index.Entry write(InputStream in, String name, String mime, String folder, byte[] thumbnail, long added) throws IOException {
		String id = hex(Crypto.random(12));
		String file = id + ".sg";
		String thumbFile = "";
		try {
			try (OutputStream out = store.create(file)) {
				Crypto.encrypt(master, in, out);
			}
			if (thumbnail != null) {
				thumbFile = id + ".t";
				try (OutputStream out = store.create(thumbFile)) {
					out.write(Crypto.encryptBytes(master, thumbnail));
				}
			}
			return new Index.Entry(id, name, folder, mime, file, thumbFile, Crypto.plainSize(store.length(file)), added);
		} catch (IOException | RuntimeException e) {
			quietDelete(file);
			quietDelete(thumbFile);
			throw e;
		}
	}

	/** Replaces the content of a file (for example by a version without metadata). It keeps its place and its thumbnail. */
	synchronized Index.Entry replace(Index.Entry old, InputStream in, String name, String mime) throws IOException {
		byte[] thumbnail = readThumbnail(old);
		Index.Entry fresh = write(in, name, mime, old.folder, thumbnail, old.added);
		int position = index.entries.indexOf(old);
		if (position < 0) {
			quietDelete(fresh.file);
			quietDelete(fresh.thumb);
			throw new IOException("The file is not in the vault any more");
		}
		index.entries.set(position, fresh);
		try {
			saveIndex();
		} catch (IOException | RuntimeException e) {
			index.entries.set(position, old);
			quietDelete(fresh.file);
			quietDelete(fresh.thumb);
			throw e;
		}
		quietDelete(old.file);
		quietDelete(old.thumb);
		return fresh;
	}

	/** Moves the files that were put in the inbox (without the password) into the vault. */
	int collectInbox() throws IOException {
		Store inbox = store.child(INBOX, false);
		if (inbox == null) {
			return 0;
		}
		List<String> names = inbox.list();
		byte[] privateKey = null;
		int count = 0;
		for (String n : names) {
			if (!n.endsWith(".m")) {
				continue;
			}
			if (privateKey == null) {
				privateKey = Crypto.decryptBytes(master, readAll(store.open(INBOX_KEY)));
			}
			try {
				Inbox.Item item = Inbox.readMeta(inbox, n, privateKey);
				String dataName = item.id + ".d";
				Crypto.RandomSource source = inbox.randomAccess(dataName);
				Crypto.Reader reader;
				try {
					reader = new Crypto.Reader(item.key, source, inbox.length(dataName));
				} catch (IOException | RuntimeException e) {
					source.close();
					throw e;
				}
				try (InputStream in = new ReaderStream(reader, true)) {
					addFile(in, item.name, item.mime, "", item.thumbnail);
				}
				inbox.delete(dataName);
				inbox.delete(n);
				count++;
			} catch (IOException e) {
				// this item stays in the inbox and is tried again the next time
			}
		}
		return count;
	}

	// ----- reading -----

	synchronized byte[] readThumbnail(Index.Entry entry) throws IOException {
		if (entry.thumb.isEmpty()) {
			return null;
		}
		return Crypto.decryptBytes(master, readAll(store.open(entry.thumb)));
	}

	Crypto.Reader openReader(Index.Entry entry) throws IOException {
		Crypto.RandomSource source = store.randomAccess(entry.file);
		try {
			return new Crypto.Reader(master, source, store.length(entry.file));
		} catch (IOException | RuntimeException e) {
			source.close();
			throw e;
		}
	}

	void export(Index.Entry entry, OutputStream out) throws IOException {
		try (Crypto.Reader reader = openReader(entry)) {
			byte[] buf = new byte[Crypto.CHUNK];
			long position = 0;
			int n;
			while ((n = reader.read(position, buf, 0, buf.length)) > 0) {
				out.write(buf, 0, n);
				position += n;
			}
		}
	}

	// ----- changing -----

	synchronized void createFolder(String path) throws IOException {
		index.folders.add(path);
		saveIndex();
	}

	synchronized void delete(Collection<Index.Entry> entries) throws IOException {
		for (Index.Entry e : entries) {
			quietDelete(e.file);
			quietDelete(e.thumb);
			index.entries.remove(e);
		}
		saveIndex();
	}

	/** Deletes the folder with everything in it. */
	synchronized void deleteFolder(String path) throws IOException {
		List<Index.Entry> inside = new ArrayList<>();
		for (Index.Entry e : index.entries) {
			if (e.folder.equals(path) || e.folder.startsWith(path + "/")) {
				inside.add(e);
			}
		}
		for (Index.Entry e : inside) {
			quietDelete(e.file);
			quietDelete(e.thumb);
		}
		index.entries.removeAll(inside);
		index.folders.removeIf(f -> f.equals(path) || f.startsWith(path + "/"));
		saveIndex();
	}

	synchronized void move(Collection<Index.Entry> entries, String folder) throws IOException {
		for (Index.Entry e : entries) {
			e.folder = folder;
		}
		saveIndex();
	}

	synchronized void rename(Index.Entry entry, String name) throws IOException {
		entry.name = name;
		saveIndex();
	}

	private void quietDelete(String name) {
		try {
			if (name != null && !name.isEmpty() && store.exists(name)) {
				store.delete(name);
			}
		} catch (IOException ignored) {
			// leaves a file nobody refers to
		}
	}

	private static String hex(byte[] b) {
		StringBuilder s = new StringBuilder();
		for (byte x : b) {
			s.append(String.format("%02x", x));
		}
		return s.toString();
	}

	static List<Index.Entry> sortedNewestFirst(List<Index.Entry> entries) {
		List<Index.Entry> copy = new ArrayList<>(entries);
		Collections.sort(copy, (a, b) -> Long.compare(b.added, a.added));
		return copy;
	}
}
