package app.safegallery;

import android.content.Context;
import android.content.SharedPreferences;

/** What the person chose in the settings screen. */
final class Settings {

	static final int LOCK_NEVER = -1;

	private static SharedPreferences prefs;

	private Settings() {
	}

	private static synchronized SharedPreferences p(Context context) {
		if (prefs == null) {
			prefs = context.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
		}
		return prefs;
	}

	/** Milliseconds the vault stays open after the app is left: 0 is "lock at once", -1 is "never". */
	static long lockDelay(Context c) {
		return p(c).getLong("lockDelay", 0L);
	}

	static void setLockDelay(Context c, long ms) {
		p(c).edit().putLong("lockDelay", ms).apply();
	}

	static boolean lockOnScreenOff(Context c) {
		return p(c).getBoolean("screenOff", true);
	}

	static void setLockOnScreenOff(Context c, boolean v) {
		p(c).edit().putBoolean("screenOff", v).apply();
	}

	static boolean lockOnShake(Context c) {
		return p(c).getBoolean("shake", false);
	}

	static void setLockOnShake(Context c, boolean v) {
		p(c).edit().putBoolean("shake", v).apply();
	}

	/** 0 low (needs a hard shake), 1 medium, 2 high (a light shake is enough). */
	static int shakeSensitivity(Context c) {
		return p(c).getInt("shakeLevel", 1);
	}

	static void setShakeSensitivity(Context c, int v) {
		p(c).edit().putInt("shakeLevel", v).apply();
	}

	static boolean blockScreenshots(Context c) {
		return p(c).getBoolean("secure", true);
	}

	static void setBlockScreenshots(Context c, boolean v) {
		p(c).edit().putBoolean("secure", v).apply();
	}

	/** True: a file that is sent to the vault is moved (the original is deleted). False: it is copied. */
	static boolean shareMove(Context c) {
		return p(c).getBoolean("shareMove", false);
	}

	static void setShareMove(Context c, boolean v) {
		p(c).edit().putBoolean("shareMove", v).apply();
	}

	static boolean externalVideoPlayer(Context c) {
		return p(c).getBoolean("externalVideo", false);
	}

	static void setExternalVideoPlayer(Context c, boolean v) {
		p(c).edit().putBoolean("externalVideo", v).apply();
	}

	static boolean autoClean(Context c) {
		return p(c).getBoolean("autoClean", false);
	}

	static void setAutoClean(Context c, boolean v) {
		p(c).edit().putBoolean("autoClean", v).apply();
	}
}
