package app.safegallery;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ParcelFileDescriptor;
import android.os.ProxyFileDescriptorCallback;
import android.os.storage.StorageManager;
import android.provider.OpenableColumns;
import android.system.ErrnoException;
import android.system.OsConstants;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/**
 * Hands a decrypted file to the app that plays or shows it, without writing it anywhere: the other app reads (and
 * seeks in) the file and every read is decrypted on the fly. It only works while the vault is unlocked.
 */
public class VaultProvider extends ContentProvider {

	static final String AUTH = "app.safegallery.files";

	@Override
	public boolean onCreate() {
		return true;
	}

	private Index.Entry entryOf(Uri uri) throws FileNotFoundException {
		Vault vault = Session.vault;
		if (vault == null) {
			throw new FileNotFoundException("The vault is locked");
		}
		List<String> segments = uri.getPathSegments();
		if (segments.size() < 2 || !"f".equals(segments.get(0))) {
			throw new FileNotFoundException(uri.toString());
		}
		Index.Entry entry = vault.find(segments.get(1));
		if (entry == null) {
			throw new FileNotFoundException(uri.toString());
		}
		return entry;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		try {
			Index.Entry entry = entryOf(uri);
			String[] columns = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
			MatrixCursor cursor = new MatrixCursor(columns);
			Object[] row = new Object[columns.length];
			for (int i = 0; i < columns.length; i++) {
				if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) {
					row[i] = entry.name;
				} else if (OpenableColumns.SIZE.equals(columns[i])) {
					row[i] = entry.size;
				}
			}
			cursor.addRow(row);
			return cursor;
		} catch (FileNotFoundException e) {
			return null;
		}
	}

	@Override
	public String getType(Uri uri) {
		try {
			return entryOf(uri).mime;
		} catch (FileNotFoundException e) {
			return null;
		}
	}

	@Override
	public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
		Index.Entry entry = entryOf(uri);
		final Crypto.Reader reader;
		try {
			reader = Session.vault.openReader(entry);
		} catch (IOException e) {
			throw new FileNotFoundException(e.toString());
		}
		final HandlerThread thread = new HandlerThread("VaultFd", android.os.Process.THREAD_PRIORITY_FOREGROUND);
		thread.start();
		Context context = getContext();
		StorageManager storage = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
		try {
			return storage.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY, new ProxyFileDescriptorCallback() {
				@Override
				public long onGetSize() {
					return reader.size();
				}

				@Override
				public int onRead(long offset, int size, byte[] data) throws ErrnoException {
					try {
						int total = 0;
						while (total < size) {
							int n = reader.read(offset + total, data, total, size - total);
							if (n <= 0) {
								break;
							}
							total += n;
						}
						return total;
					} catch (IOException e) {
						throw new ErrnoException("read", OsConstants.EIO);
					}
				}

				@Override
				public void onRelease() {
					try {
						reader.close();
					} catch (IOException ignored) {
						// already closed
					} finally {
						thread.quitSafely();
					}
				}
			}, new Handler(thread.getLooper()));
		} catch (IOException e) {
			thread.quitSafely();
			try {
				reader.close();
			} catch (IOException ignored) {
				// already closed
			}
			throw new FileNotFoundException(e.toString());
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		return null;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		return 0;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		return 0;
	}
}
