package app.safegallery;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A vault folder chosen with the system folder picker. Nothing is listed until a file is really needed. */
final class SafStore implements Store {

	private final ContentResolver resolver;
	private final Uri tree;
	private final String dirId;
	private final Uri dirUri;
	private final Map<String, String> ids = new HashMap<>();
	private boolean listed;

	SafStore(Context context, Uri tree) {
		this(context.getContentResolver(), tree, DocumentsContract.getTreeDocumentId(tree));
	}

	private SafStore(ContentResolver resolver, Uri tree, String dirId) {
		this.resolver = resolver;
		this.tree = tree;
		this.dirId = dirId;
		this.dirUri = DocumentsContract.buildDocumentUriUsingTree(tree, dirId);
	}

	Uri treeUri() {
		return tree;
	}

	private synchronized void listAll() {
		ids.clear();
		Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dirId);
		try (Cursor c = resolver.query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
			while (c != null && c.moveToNext()) {
				ids.put(c.getString(1), c.getString(0));
			}
		} catch (RuntimeException e) {
			// an unreadable folder looks empty
		}
		listed = true;
	}

	/** Finds the id of a file: from memory, by guessing the id (fast, works on the phone's own storage) or by listing. */
	private synchronized String idOf(String name) {
		String id = ids.get(name);
		if (id != null) {
			return id;
		}
		String guess = dirId.endsWith("/") ? dirId + name : dirId + "/" + name;
		String shown = displayName(DocumentsContract.buildDocumentUriUsingTree(tree, guess));
		if (name.equals(shown)) {
			ids.put(name, guess);
			return guess;
		}
		if (!listed) {
			listAll();
		}
		return ids.get(name);
	}

	private Uri uriOf(String name) throws FileNotFoundException {
		String id = idOf(name);
		if (id == null) {
			throw new FileNotFoundException(name);
		}
		return DocumentsContract.buildDocumentUriUsingTree(tree, id);
	}

	@Override
	public boolean exists(String name) {
		return idOf(name) != null;
	}

	@Override
	public synchronized List<String> list() {
		listAll();
		return new ArrayList<>(ids.keySet());
	}

	@Override
	public synchronized Store child(String name, boolean create) throws IOException {
		String id = idOf(name);
		if (id == null) {
			if (!create) {
				return null;
			}
			Uri made = DocumentsContract.createDocument(resolver, dirUri, DocumentsContract.Document.MIME_TYPE_DIR, name);
			if (made == null) {
				throw new IOException("Could not create folder " + name);
			}
			id = DocumentsContract.getDocumentId(made);
			ids.put(name, id);
		}
		return new SafStore(resolver, tree, id);
	}

	@Override
	public synchronized OutputStream create(String name) throws IOException {
		Uri uri;
		if (idOf(name) != null) {
			uri = uriOf(name);
		} else {
			uri = DocumentsContract.createDocument(resolver, dirUri, "application/octet-stream", name);
			if (uri == null) {
				throw new IOException("Could not create " + name);
			}
			String actual = displayName(uri);
			if (actual != null && !actual.equals(name)) {
				Uri renamed = DocumentsContract.renameDocument(resolver, uri, name);
				if (renamed != null) {
					uri = renamed;
				}
			}
			ids.put(name, DocumentsContract.getDocumentId(uri));
		}
		OutputStream out = resolver.openOutputStream(uri, "wt");
		if (out == null) {
			throw new IOException("Could not write " + name);
		}
		return new BufferedOutputStream(out, 1 << 16);
	}

	@Override
	public InputStream open(String name) throws IOException {
		InputStream in = resolver.openInputStream(uriOf(name));
		if (in == null) {
			throw new FileNotFoundException(name);
		}
		return new BufferedInputStream(in, 1 << 16);
	}

	@Override
	public long length(String name) throws IOException {
		Uri uri = uriOf(name);
		try (Cursor c = resolver.query(uri, new String[]{DocumentsContract.Document.COLUMN_SIZE}, null, null, null)) {
			if (c != null && c.moveToFirst() && !c.isNull(0)) {
				return c.getLong(0);
			}
		}
		try (ParcelFileDescriptor pfd = resolver.openFileDescriptor(uri, "r")) {
			if (pfd != null) {
				return pfd.getStatSize();
			}
		}
		throw new IOException("Unknown size of " + name);
	}

	@Override
	public Crypto.RandomSource randomAccess(String name) throws IOException {
		final ParcelFileDescriptor pfd = resolver.openFileDescriptor(uriOf(name), "r");
		if (pfd == null) {
			throw new FileNotFoundException(name);
		}
		final FileInputStream stream = new FileInputStream(pfd.getFileDescriptor());
		final FileChannel channel = stream.getChannel();
		return new Crypto.RandomSource() {
			@Override
			public int readAt(long position, byte[] dst, int off, int len) throws IOException {
				return channel.read(ByteBuffer.wrap(dst, off, len), position);
			}

			@Override
			public void close() throws IOException {
				try {
					stream.close();
				} finally {
					pfd.close();
				}
			}
		};
	}

	@Override
	public synchronized void delete(String name) throws IOException {
		if (idOf(name) == null) {
			return;
		}
		DocumentsContract.deleteDocument(resolver, uriOf(name));
		ids.remove(name);
	}

	private String displayName(Uri uri) {
		try (Cursor c = resolver.query(uri, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
			if (c != null && c.moveToFirst()) {
				return c.getString(0);
			}
		} catch (RuntimeException e) {
			// not there
		}
		return null;
	}
}
