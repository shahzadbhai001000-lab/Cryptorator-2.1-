package app.safegallery;

/** Marks the screens that show the content of a vault. They are closed when the vault locks. */
interface LockAware {
}
