package app.safegallery;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/** An image that can be zoomed with two fingers or a double tap, and moved around when it is zoomed. */
final class ZoomImageView extends ImageView {

	private final Matrix matrix = new Matrix();
	private final float[] values = new float[9];
	private final RectF rect = new RectF();
	private final ScaleGestureDetector scaler;
	private final GestureDetector gestures;
	private float fitScale = 1f;
	private float lastX;
	private float lastY;
	private int activePointer = -1;
	private Runnable onTap;

	ZoomImageView(Context context) {
		super(context);
		setScaleType(ScaleType.MATRIX);
		scaler = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
			@Override
			public boolean onScale(ScaleGestureDetector d) {
				zoomBy(d.getScaleFactor(), d.getFocusX(), d.getFocusY());
				return true;
			}
		});
		gestures = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
			@Override
			public boolean onSingleTapConfirmed(MotionEvent e) {
				if (onTap != null) {
					onTap.run();
				}
				return true;
			}

			@Override
			public boolean onDoubleTap(MotionEvent e) {
				float now = currentScale();
				if (now > fitScale * 1.05f) {
					fit();
				} else {
					zoomBy(Math.min(3f, 4f * fitScale / now), e.getX(), e.getY());
				}
				return true;
			}
		});
	}

	void setOnTap(Runnable r) {
		onTap = r;
	}

	@Override
	public void setImageDrawable(Drawable drawable) {
		super.setImageDrawable(drawable);
		fit();
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		fit();
	}

	private float currentScale() {
		matrix.getValues(values);
		return values[Matrix.MSCALE_X];
	}

	private void fit() {
		Drawable d = getDrawable();
		matrix.reset();
		if (d != null && getWidth() > 0 && getHeight() > 0 && d.getIntrinsicWidth() > 0 && d.getIntrinsicHeight() > 0) {
			float dw = d.getIntrinsicWidth();
			float dh = d.getIntrinsicHeight();
			fitScale = Math.min(getWidth() / dw, getHeight() / dh);
			matrix.postScale(fitScale, fitScale);
			matrix.postTranslate((getWidth() - dw * fitScale) / 2f, (getHeight() - dh * fitScale) / 2f);
		}
		setImageMatrix(matrix);
	}

	private void zoomBy(float factor, float px, float py) {
		float now = currentScale();
		float target = Math.max(fitScale, Math.min(now * factor, fitScale * 8f));
		factor = target / now;
		matrix.postScale(factor, factor, px, py);
		fixBounds();
		setImageMatrix(matrix);
	}

	private boolean bounds() {
		Drawable d = getDrawable();
		if (d == null) {
			return false;
		}
		rect.set(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
		matrix.mapRect(rect);
		return true;
	}

	private void fixBounds() {
		if (!bounds()) {
			return;
		}
		float dx = 0;
		float dy = 0;
		if (rect.width() <= getWidth()) {
			dx = (getWidth() - rect.width()) / 2f - rect.left;
		} else if (rect.left > 0) {
			dx = -rect.left;
		} else if (rect.right < getWidth()) {
			dx = getWidth() - rect.right;
		}
		if (rect.height() <= getHeight()) {
			dy = (getHeight() - rect.height()) / 2f - rect.top;
		} else if (rect.top > 0) {
			dy = -rect.top;
		} else if (rect.bottom < getHeight()) {
			dy = getHeight() - rect.bottom;
		}
		matrix.postTranslate(dx, dy);
	}

	/** @param direction 1 if the finger moves to the right, -1 to the left */
	boolean canPan(int direction) {
		if (!bounds() || rect.width() <= getWidth() + 1) {
			return false;
		}
		return direction > 0 ? rect.left < -1 : rect.right > getWidth() + 1;
	}

	@Override
	public boolean onTouchEvent(MotionEvent e) {
		scaler.onTouchEvent(e);
		gestures.onTouchEvent(e);
		switch (e.getActionMasked()) {
			case MotionEvent.ACTION_DOWN:
				activePointer = e.getPointerId(0);
				lastX = e.getX();
				lastY = e.getY();
				break;
			case MotionEvent.ACTION_POINTER_DOWN:
			case MotionEvent.ACTION_POINTER_UP: {
				int index = e.getActionIndex();
				if (e.getActionMasked() == MotionEvent.ACTION_POINTER_UP && e.getPointerId(index) == activePointer) {
					index = index == 0 ? 1 : 0;
				} else if (e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
					index = 0;
				}
				if (index < e.getPointerCount()) {
					activePointer = e.getPointerId(index);
					lastX = e.getX(index);
					lastY = e.getY(index);
				}
				break;
			}
			case MotionEvent.ACTION_MOVE: {
				int index = e.findPointerIndex(activePointer);
				if (index < 0) {
					break;
				}
				float x = e.getX(index);
				float y = e.getY(index);
				if (!scaler.isInProgress() && currentScale() > fitScale * 1.01f) {
					matrix.postTranslate(x - lastX, y - lastY);
					fixBounds();
					setImageMatrix(matrix);
				}
				lastX = x;
				lastY = y;
				break;
			}
			default:
				break;
		}
		return true;
	}
}
