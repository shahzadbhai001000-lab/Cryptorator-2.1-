package app.safegallery;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/** Where the files of a vault are kept: one folder, which can have a few sub folders. */
interface Store {

	boolean exists(String name) throws IOException;

	/** Creates the file, or replaces it if it exists. */
	OutputStream create(String name) throws IOException;

	InputStream open(String name) throws IOException;

	long length(String name) throws IOException;

	Crypto.RandomSource randomAccess(String name) throws IOException;

	void delete(String name) throws IOException;

	/** The names of everything in this folder. This can be slow in a folder with many files. */
	List<String> list() throws IOException;

	/** A sub folder, or null if there is none and [create] is false. */
	Store child(String name, boolean create) throws IOException;
}
