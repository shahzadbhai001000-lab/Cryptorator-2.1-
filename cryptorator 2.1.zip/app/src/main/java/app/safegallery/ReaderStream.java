package app.safegallery;

import java.io.IOException;
import java.io.InputStream;

/** The content of an encrypted file as a normal stream. */
final class ReaderStream extends InputStream {

	private final Crypto.Reader reader;
	private final boolean closeReader;
	private long position;

	ReaderStream(Crypto.Reader reader, boolean closeReader) {
		this.reader = reader;
		this.closeReader = closeReader;
	}

	@Override
	public int read() throws IOException {
		byte[] one = new byte[1];
		int n = read(one, 0, 1);
		return n <= 0 ? -1 : one[0] & 0xFF;
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		if (len == 0) {
			return 0;
		}
		int n = reader.read(position, b, off, len);
		if (n > 0) {
			position += n;
		}
		return n;
	}

	@Override
	public long skip(long n) {
		long skipped = Math.max(0, Math.min(n, reader.size() - position));
		position += skipped;
		return skipped;
	}

	@Override
	public int available() {
		return (int) Math.min(Integer.MAX_VALUE, reader.size() - position);
	}

	@Override
	public void close() throws IOException {
		if (closeReader) {
			reader.close();
		}
	}
}
