package app.safegallery;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Lets files be put into a vault without its password. The vault has a public key (kept in its folder, not secret) and
 * a private key (kept in the vault, encrypted with the vault key). A file that is put in is encrypted with a key that
 * only the private key can recover. The next time the vault is unlocked the files are moved from the inbox into it.
 */
final class Inbox {

	private static final byte[] MAGIC = {'S', 'G', 'I', '1'};

	private Inbox() {
	}

	static final class Keys {
		final byte[] publicKey;
		final byte[] privateKey;

		Keys(byte[] publicKey, byte[] privateKey) {
			this.publicKey = publicKey;
			this.privateKey = privateKey;
		}
	}

	static final class Item {
		String id;
		String name;
		String mime;
		byte[] thumbnail;
		byte[] key;
	}

	static Keys generateKeys() throws IOException {
		try {
			KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
			generator.initialize(new ECGenParameterSpec("secp256r1"));
			KeyPair pair = generator.generateKeyPair();
			return new Keys(pair.getPublic().getEncoded(), pair.getPrivate().getEncoded());
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		}
	}

	private static byte[] sharedKey(PrivateKey priv, PublicKey pub) throws GeneralSecurityException {
		KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
		agreement.init(priv);
		agreement.doPhase(pub, true);
		byte[] secret = agreement.generateSecret();
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(new SecretKeySpec(secret, "HmacSHA256"));
		return mac.doFinal("SafeGallery inbox key 1".getBytes(StandardCharsets.UTF_8));
	}

	/** Puts a file in the inbox. The file only becomes visible to the vault once it is complete. */
	static void deposit(Store inbox, byte[] vaultPublicKey, String name, String mime, byte[] thumbnail, InputStream data) throws IOException {
		String id = hex(Crypto.random(12));
		try {
			KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
			generator.initialize(new ECGenParameterSpec("secp256r1"));
			KeyPair ephemeral = generator.generateKeyPair();
			PublicKey vault = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(vaultPublicKey));
			byte[] key = sharedKey(ephemeral.getPrivate(), vault);

			try (OutputStream out = inbox.create(id + ".d")) {
				Crypto.encrypt(key, data, out);
			}

			ByteArrayOutputStream meta = new ByteArrayOutputStream();
			DataOutputStream metaOut = new DataOutputStream(meta);
			metaOut.writeUTF(name);
			metaOut.writeUTF(mime);
			byte[] thumb = thumbnail != null ? thumbnail : new byte[0];
			metaOut.writeInt(thumb.length);
			metaOut.write(thumb);
			metaOut.flush();

			byte[] ephemeralPublic = ephemeral.getPublic().getEncoded();
			ByteArrayOutputStream file = new ByteArrayOutputStream();
			DataOutputStream fileOut = new DataOutputStream(file);
			fileOut.write(MAGIC);
			fileOut.writeShort(ephemeralPublic.length);
			fileOut.write(ephemeralPublic);
			fileOut.write(Crypto.encryptBytes(key, meta.toByteArray()));
			fileOut.flush();
			try (OutputStream out = inbox.create(id + ".m")) {
				out.write(file.toByteArray());
			}
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		} catch (IOException | RuntimeException e) {
			quietDelete(inbox, id + ".d");
			quietDelete(inbox, id + ".m");
			throw e;
		}
	}

	/** Reads what belongs to an item of the inbox. The data of the item is in [id].d */
	static Item readMeta(Store inbox, String metaName, byte[] vaultPrivateKey) throws IOException {
		byte[] file;
		try (InputStream in = inbox.open(metaName)) {
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			byte[] buf = new byte[8192];
			int n;
			while ((n = in.read(buf)) >= 0) {
				bytes.write(buf, 0, n);
			}
			file = bytes.toByteArray();
		}
		try {
			DataInputStream in = new DataInputStream(new ByteArrayInputStream(file));
			byte[] magic = new byte[4];
			in.readFully(magic);
			if (!Arrays.equals(magic, MAGIC)) {
				throw new IOException("Not an inbox item");
			}
			byte[] ephemeralPublic = new byte[in.readUnsignedShort()];
			in.readFully(ephemeralPublic);
			byte[] encryptedMeta = new byte[in.available()];
			in.readFully(encryptedMeta);

			PublicKey ephemeral = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(ephemeralPublic));
			PrivateKey priv = KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(vaultPrivateKey));
			byte[] key = sharedKey(priv, ephemeral);

			DataInputStream meta = new DataInputStream(new ByteArrayInputStream(Crypto.decryptBytes(key, encryptedMeta)));
			Item item = new Item();
			item.id = metaName.substring(0, metaName.length() - 2);
			item.name = meta.readUTF();
			item.mime = meta.readUTF();
			byte[] thumb = new byte[meta.readInt()];
			meta.readFully(thumb);
			item.thumbnail = thumb.length == 0 ? null : thumb;
			item.key = key;
			return item;
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		}
	}

	private static void quietDelete(Store store, String name) {
		try {
			if (store.exists(name)) {
				store.delete(name);
			}
		} catch (IOException ignored) {
			// leaves an unfinished file that is never read
		}
	}

	private static String hex(byte[] b) {
		StringBuilder s = new StringBuilder();
		for (byte x : b) {
			s.append(String.format("%02x", x));
		}
		return s.toString();
	}
}
